# BITTADA - Complete API Reference

## Overview

All API endpoints are RESTful and require proper authentication with JWT tokens (except where noted). Base URL: `/api`

## Authentication

### Headers Required (Protected Routes)
```
Authorization: Bearer {jwt_token}
Content-Type: application/json
```

---

## 🔐 Authentication Endpoints

### 1. Register User
**POST** `/api/auth/register`

Register a new customer or seller account.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123",
  "full_name": "John Doe",
  "phone": "+998901234567",
  "role": "customer"
}
```

**Response (201):**
```json
{
  "success": true,
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "full_name": "John Doe",
    "phone": "+998901234567",
    "role": "customer"
  },
  "token": "eyJhbGc..."
}
```

**Errors:**
- 400: Missing fields, invalid email, invalid phone
- 409: Email or phone already registered

---

### 2. Login
**POST** `/api/auth/login`

Authenticate a user and receive JWT token.

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response (200):**
```json
{
  "success": true,
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "full_name": "John Doe",
    "phone": "+998901234567",
    "role": "customer"
  },
  "token": "eyJhbGc..."
}
```

**Errors:**
- 401: Invalid credentials
- 403: Account inactive

---

### 3. Get Profile
**GET** `/api/auth/profile`

Get authenticated user's profile.

**Authentication:** Required ✅

**Response (200):**
```json
{
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "full_name": "John Doe",
    "phone": "+998901234567",
    "role": "customer",
    "avatar_url": "https://..."
  }
}
```

---

## 🛍️ Product Endpoints

### 4. Create Product
**POST** `/api/products/create`

Create a new product (seller only).

**Authentication:** Required (Seller) ✅

**Request Body:**
```json
{
  "name": "Product Name",
  "description": "Detailed description",
  "price": 50000,
  "category_id": "uuid",
  "sku": "SKU-001",
  "stock_quantity": 10,
  "weight": 500,
  "dimensions": {
    "length": 10,
    "width": 5,
    "height": 3
  }
}
```

**Response (200):**
```json
{
  "success": true,
  "product": {
    "id": "uuid",
    "seller_id": "uuid",
    "name": "Product Name",
    "price": "50000",
    "status": "draft",
    "stock_quantity": 10,
    "created_at": "2024-08-24T..."
  }
}
```

**Errors:**
- 401: Not authenticated
- 403: Not a seller or seller not verified
- 400: Invalid product data

---

### 5. Submit Product for Review
**POST** `/api/products/submit-for-review`

Submit a draft product for admin approval.

**Authentication:** Required (Seller) ✅

**Request Body:**
```json
{
  "product_id": "uuid"
}
```

**Response (200):**
```json
{
  "success": true,
  "product": {
    "id": "uuid",
    "status": "pending_review"
  },
  "message": "Product submitted for review"
}
```

**Errors:**
- 404: Product not found
- 400: Product not in draft status

---

### 6. List Approved Products
**GET** `/api/products/list?page=1&limit=20`

Get list of approved products for marketplace.

**Authentication:** Not required

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 20)

**Response (200):**
```json
{
  "products": [
    {
      "id": "uuid",
      "name": "Product Name",
      "price": "50000",
      "rating": "4.5",
      "images": [
        {
          "id": "uuid",
          "image_url": "https://..."
        }
      ]
    }
  ],
  "page": 1,
  "limit": 20,
  "total": 100
}
```

---

## 🛒 Shopping Cart Endpoints

### 7. Add to Cart
**POST** `/api/cart/add`

Add a product to customer's shopping cart.

**Authentication:** Required (Customer) ✅

**Request Body:**
```json
{
  "product_id": "uuid",
  "quantity": 1
}
```

**Response (200):**
```json
{
  "success": true,
  "item": {
    "id": "uuid",
    "product_id": "uuid",
    "quantity": 1,
    "price_at_addition": "50000"
  }
}
```

**Errors:**
- 404: Product not found
- 400: Insufficient stock

---

### 8. Get Cart
**GET** `/api/cart/get`

Get customer's shopping cart with all items.

**Authentication:** Required (Customer) ✅

**Response (200):**
```json
{
  "cart": {
    "id": "uuid",
    "customer_id": "uuid",
    "expires_at": "2024-08-31T..."
  },
  "items": [
    {
      "id": "uuid",
      "product_id": "uuid",
      "quantity": 1,
      "price_at_addition": "50000",
      "product": {
        "id": "uuid",
        "name": "Product Name",
        "price": "50000"
      },
      "line_total": 50000
    }
  ],
  "subtotal": 50000,
  "delivery_fee": 0,
  "discount": 0,
  "total": 50000,
  "item_count": 1
}
```

---

### 9. Remove from Cart
**POST** `/api/cart/remove`

Remove an item from customer's cart.

**Authentication:** Required (Customer) ✅

**Request Body:**
```json
{
  "item_id": "uuid"
}
```

**Response (200):**
```json
{
  "success": true,
  "message": "Item removed from cart"
}
```

---

## 📦 Order Endpoints

### 10. Create Order
**POST** `/api/orders/create`

Create a new order with automatic pickup code generation.

**Authentication:** Required (Customer) ✅

**Request Body:**
```json
{
  "pickup_point_id": "uuid",
  "payment_method": "cash_on_delivery",
  "customer_notes": "Please ring the doorbell"
}
```

**Response (200):**
```json
{
  "success": true,
  "order": {
    "id": "uuid",
    "order_number": "BT...",
    "pickup_code": "4827",
    "total": "50000"
  }
}
```

**Key Features:**
- ✅ Validates product stock
- ✅ Generates unique 4-digit pickup code
- ✅ Calculates prices server-side
- ✅ Clears cart on successful order
- ✅ Creates order status history

**Errors:**
- 400: Invalid pickup point, insufficient stock
- 404: Cart not found

---

### 11. Get Order Details
**GET** `/api/orders/get?order_id=uuid`

Get details of a specific order.

**Authentication:** Required ✅

**Query Parameters:**
- `order_id` (optional): Get specific order. If omitted, lists customer's orders.

**Response (200):**
```json
{
  "order": {
    "id": "uuid",
    "order_number": "BT...",
    "pickup_code": "4827",
    "status": "new",
    "total": "50000",
    "items": [
      {
        "id": "uuid",
        "product_name": "Product",
        "quantity": 1,
        "price_per_unit": "50000",
        "status": "new"
      }
    ],
    "pickup_point": {
      "id": "uuid",
      "name": "Pickup Point",
      "address": "123 Main St",
      "phone": "+998901234567"
    }
  }
}
```

---

### 12. Update Order Status
**POST** `/api/orders/update-status`

Update order status (seller/admin only).

**Authentication:** Required (Seller/Admin) ✅

**Request Body:**
```json
{
  "order_id": "uuid",
  "new_status": "confirmed"
}
```

**Valid Statuses:**
- `new` → `confirmed` → `preparing` → `ready_for_shipment` → `shipped` → `at_warehouse` → `at_pickup_point` → `completed`
- `cancelled`
- `return_requested`

**Response (200):**
```json
{
  "success": true,
  "order": {
    "id": "uuid",
    "status": "confirmed",
    "updated_at": "2024-08-24T..."
  }
}
```

---

## 👤 Seller Endpoints

### 13. Register Seller Profile
**POST** `/api/sellers/register`

Create a seller profile (requires existing customer account).

**Authentication:** Required ✅

**Request Body:**
```json
{
  "business_name": "My Store",
  "seller_type": "individual",
  "address": "123 Main St",
  "city": "Toshkent",
  "phone": "+998901234567",
  "description": "My store description"
}
```

**Response (200):**
```json
{
  "success": true,
  "profile": {
    "id": "uuid",
    "user_id": "uuid",
    "business_name": "My Store",
    "verification_status": "pending"
  },
  "message": "Seller profile created. Awaiting admin verification."
}
```

---

### 14. Get Seller Profile
**GET** `/api/sellers/profile`

Get authenticated seller's profile.

**Authentication:** Required (Seller) ✅

**Response (200):**
```json
{
  "seller": {
    "id": "uuid",
    "user_id": "uuid",
    "business_name": "My Store",
    "verification_status": "approved",
    "rating": "4.5",
    "total_products": 10,
    "total_orders": 25
  }
}
```

---

### 15. Get Seller's Products
**GET** `/api/sellers/products`

Get all products from authenticated seller.

**Authentication:** Required (Seller) ✅

**Response (200):**
```json
{
  "products": [
    {
      "id": "uuid",
      "name": "Product",
      "price": "50000",
      "status": "approved",
      "stock_quantity": 10,
      "images": [...]
    }
  ]
}
```

---

### 16. Get Seller's Orders
**GET** `/api/sellers/orders`

Get all orders containing seller's products.

**Authentication:** Required (Seller) ✅

**Response (200):**
```json
{
  "orders": [
    {
      "order_item": {
        "id": "uuid",
        "quantity": 1,
        "price_per_unit": "50000"
      },
      "order": {
        "id": "uuid",
        "order_number": "BT...",
        "pickup_code": "4827",
        "status": "new",
        "customer_phone": "+998901234567"
      },
      "product": {
        "id": "uuid",
        "name": "Product Name"
      },
      "pickup_point": {
        "id": "uuid",
        "name": "Pickup Point",
        "address": "123 Main St"
      }
    }
  ],
  "total": 5
}
```

---

### 17. Get Seller Statistics
**GET** `/api/sellers/stats`

Get seller dashboard statistics.

**Authentication:** Required (Seller) ✅

**Response (200):**
```json
{
  "stats": {
    "total_products": 10,
    "active_products": 8,
    "total_orders": 25,
    "pending_orders": 3,
    "revenue": "1250000",
    "verification_status": "approved",
    "rating": "4.5"
  }
}
```

---

## ⭐ Review Endpoints

### 18. Create Review
**POST** `/api/reviews/create`

Leave a review for a purchased product.

**Authentication:** Required (Customer) ✅

**Request Body:**
```json
{
  "product_id": "uuid",
  "order_item_id": "uuid",
  "rating": 5,
  "title": "Great product!",
  "text": "Excellent quality, fast shipping"
}
```

**Response (200):**
```json
{
  "success": true,
  "review": {
    "id": "uuid",
    "product_id": "uuid",
    "rating": 5,
    "title": "Great product!",
    "is_verified_purchase": true,
    "created_at": "2024-08-24T..."
  }
}
```

**Constraints:**
- ✅ Only verified purchasers can review
- ✅ One review per customer per product
- ✅ Rating must be 1-5

---

### 19. List Reviews
**GET** `/api/reviews/list?product_id=uuid`

Get all reviews for a product.

**Authentication:** Not required

**Query Parameters:**
- `product_id` (required): Product to get reviews for

**Response (200):**
```json
{
  "reviews": [
    {
      "id": "uuid",
      "rating": 5,
      "title": "Great!",
      "text": "Excellent",
      "is_verified_purchase": true,
      "created_at": "2024-08-24T..."
    }
  ],
  "average_rating": "4.7",
  "total_reviews": 15,
  "rating_distribution": {
    "5": 12,
    "4": 2,
    "3": 1,
    "2": 0,
    "1": 0
  }
}
```

---

## 🎯 Complaint Endpoints

### 20. Create Complaint
**POST** `/api/complaints/create`

File a complaint about an order (customer only).

**Authentication:** Required (Customer) ✅

**Request Body:**
```json
{
  "order_id": "uuid",
  "product_id": "uuid",
  "reason": "damaged",
  "description": "Item arrived with broken packaging and internal damage"
}
```

**Valid Reasons:**
- `mismatch` - Product does not match description
- `damaged` - Item is damaged
- `wrong_product` - Wrong product sent
- `missing_item` - Item is missing
- `quality` - Quality issue
- `other` - Other reason

**Response (200):**
```json
{
  "success": true,
  "complaint": {
    "id": "uuid",
    "complaint_number": "CM...",
    "status": "open",
    "created_at": "2024-08-24T..."
  },
  "message": "Complaint filed successfully"
}
```

---

### 21. List Complaints
**GET** `/api/complaints/list?status=open`

List complaints (role-dependent access).

**Authentication:** Required ✅

**Query Parameters:**
- `status` (optional): Filter by status (open, in_review, resolved, rejected, all)

**Access:**
- Customer: sees only their complaints
- Seller: sees complaints against their products
- Admin: sees all complaints

**Response (200):**
```json
{
  "complaints": [
    {
      "id": "uuid",
      "complaint_number": "CM...",
      "order_id": "uuid",
      "reason": "damaged",
      "status": "open",
      "created_at": "2024-08-24T..."
    }
  ],
  "total": 3
}
```

---

## 📋 Admin Endpoints

### 22. Approve/Reject Seller
**POST** `/api/admin/approve-seller`

Approve or reject a seller registration.

**Authentication:** Required (Admin) ✅

**Request Body:**
```json
{
  "seller_id": "uuid",
  "approved": true
}
```

**Response (200):**
```json
{
  "success": true,
  "seller": {
    "id": "uuid",
    "business_name": "My Store",
    "verification_status": "approved",
    "verified_at": "2024-08-24T..."
  }
}
```

---

### 23. Approve/Reject Product
**POST** `/api/admin/approve-product`

Approve or reject a product submission.

**Authentication:** Required (Admin) ✅

**Request Body:**
```json
{
  "product_id": "uuid",
  "approved": true,
  "reason": "Product meets quality standards"
}
```

**Response (200):**
```json
{
  "success": true,
  "product": {
    "id": "uuid",
    "name": "Product",
    "status": "approved"
  }
}
```

---

### 24. Process Complaint
**POST** `/api/admin/process-complaint`

Resolve a complaint with decision.

**Authentication:** Required (Admin) ✅

**Request Body:**
```json
{
  "complaint_id": "uuid",
  "resolution_type": "full_refund",
  "admin_notes": "Customer claim substantiated, full refund issued"
}
```

**Valid Resolution Types:**
- `none` - Dismissed
- `partial_refund` - Partial refund
- `full_refund` - Full refund
- `replacement` - Send replacement

**Response (200):**
```json
{
  "success": true,
  "complaint": {
    "id": "uuid",
    "status": "resolved",
    "resolution_type": "full_refund",
    "resolved_at": "2024-08-24T..."
  },
  "message": "Complaint processed successfully"
}
```

---

### 25. List Sellers (Admin)
**GET** `/api/admin/sellers?status=pending`

List sellers by verification status.

**Authentication:** Required (Admin) ✅

**Query Parameters:**
- `status` (optional): pending, approved, all (default: pending)

**Response (200):**
```json
{
  "sellers": [
    {
      "id": "uuid",
      "business_name": "Store",
      "verification_status": "pending",
      "user_id": "uuid"
    }
  ],
  "total": 5
}
```

---

### 26. List Products (Admin Review)
**GET** `/api/admin/products?status=pending_review`

List products awaiting review.

**Authentication:** Required (Admin) ✅

**Query Parameters:**
- `status` (optional): pending_review, approved, all

**Response (200):**
```json
{
  "products": [
    {
      "id": "uuid",
      "name": "Product",
      "status": "pending_review",
      "seller": { "business_name": "Store" },
      "images": [...]
    }
  ],
  "total": 8
}
```

---

### 27. Platform Statistics
**GET** `/api/admin/stats`

Get overall platform statistics.

**Authentication:** Required (Admin) ✅

**Response (200):**
```json
{
  "stats": {
    "users": {
      "total": 150,
      "customers": 130
    },
    "sellers": {
      "total": 20,
      "approved": 15,
      "pending": 5
    },
    "products": {
      "total": 450,
      "approved": 380,
      "pending": 70
    },
    "orders": {
      "total": 250,
      "revenue": "12500000"
    },
    "complaints": {
      "total": 8,
      "open": 2
    },
    "refunds": {
      "total": 3,
      "amount": "150000"
    }
  }
}
```

---

## 🏪 Utility Endpoints

### 28. List Pickup Points
**GET** `/api/pickup-points/list?city=Toshkent`

Get available pickup points.

**Authentication:** Not required

**Query Parameters:**
- `city` (optional): Filter by city

**Response (200):**
```json
{
  "points": [
    {
      "id": "uuid",
      "name": "Tashkent Center",
      "city": "Toshkent",
      "address": "123 Main St",
      "phone": "+998901234567",
      "working_hours": {
        "monday": "08:00-20:00",
        "tuesday": "08:00-20:00"
      },
      "status": "active"
    }
  ],
  "total": 5
}
```

---

### 29. Health Check
**GET** `/api/health`

Platform health status.

**Authentication:** Not required

**Response (200):**
```json
{
  "ok": true
}
```

---

## 📊 Summary

| Category | Count | Routes |
|----------|-------|--------|
| Authentication | 3 | Register, Login, Profile |
| Products | 3 | Create, Submit, List |
| Cart | 3 | Add, Get, Remove |
| Orders | 3 | Create, Get, UpdateStatus |
| Sellers | 5 | Register, Profile, Products, Orders, Stats |
| Reviews | 2 | Create, List |
| Complaints | 2 | Create, List |
| Admin | 4 | ApproveSeller, ApproveProduct, ProcessComplaint, Stats |
| Utilities | 2 | PickupPoints, Health |
| **Total** | **27** | **API Endpoints** |

---

## 🔒 Authentication Notes

- All protected endpoints require `Authorization: Bearer {token}` header
- JWT tokens expire after 7 days
- Tokens contain: `userId`, `email`, `role`
- Role-based access: `customer`, `seller`, `admin`

## Error Codes

| Code | Meaning |
|------|---------|
| 200 | Success |
| 201 | Created |
| 400 | Bad request |
| 401 | Unauthorized |
| 403 | Forbidden |
| 404 | Not found |
| 409 | Conflict |
| 500 | Server error |

---

**API v1.0 - BITTADA Marketplace**
