"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function Home() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<any>(null);
  const router = useRouter();

  useEffect(() => {
    const token = localStorage.getItem("token");
    const userData = localStorage.getItem("user");
    if (token && userData) {
      setIsLoggedIn(true);
      setUser(JSON.parse(userData));
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setIsLoggedIn(false);
    setUser(null);
    router.push("/");
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <div className="text-2xl font-bold text-blue-600">BITTADA</div>
              <span className="text-sm text-gray-600">Marketplace</span>
            </Link>

            <div className="flex-1 max-w-xl mx-8">
              <input
                type="text"
                placeholder="Qidiruv..."
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <nav className="flex items-center gap-6">
              <Link href="/orders" className="text-gray-700 hover:text-blue-600">
                Buyurtmalar
              </Link>
              <Link href="/cart" className="text-gray-700 hover:text-blue-600">
                Savatcha
              </Link>
              {isLoggedIn ? (
                <div className="flex items-center gap-4">
                  <Link href="/profile" className="text-gray-700 hover:text-blue-600">
                    Profil
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600"
                  >
                    Chiqish
                  </button>
                </div>
              ) : (
                <Link
                  href="/auth/login"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Kirish
                </Link>
              )}

              <Link
                href="/seller"
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 whitespace-nowrap"
              >
                Sotuvchi bo'lish
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <h1 className="text-5xl font-bold text-slate-900 mb-4">
            Bittada'ga xush kelibsiz
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Qulaylik. Bittada.
          </p>

          {/* Empty State */}
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-4">
              Bittada'da hozircha mahsulotlar yo'q
            </h2>
            <p className="text-gray-700 mb-8">
              Birinchi sotuvchilardan biri bo'lish uchun quyida "Sotuvchi bo'lish" tugmasini bosing.
            </p>

            <div className="flex gap-4 justify-center">
              <Link
                href="/seller"
                className="px-8 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 text-lg font-semibold"
              >
                Sotuvchi bo'lish
              </Link>
              {isLoggedIn && user?.role === "customer" && (
                <Link
                  href="/cart"
                  className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-lg font-semibold"
                >
                  Savatcha
                </Link>
              )}
            </div>
          </div>

          {/* Info Section */}
          <div className="mt-16 grid grid-cols-3 gap-8">
            <div className="bg-gray-50 rounded-lg p-8">
              <h3 className="text-lg font-bold mb-2">Xavfsiz</h3>
              <p className="text-gray-600">
                Barcha tranzaksiyalar xavfsiz va himoya qilingan
              </p>
            </div>
            <div className="bg-gray-50 rounded-lg p-8">
              <h3 className="text-lg font-bold mb-2">Tez</h3>
              <p className="text-gray-600">
                Eng tez yetkazib berish xizmati
              </p>
            </div>
            <div className="bg-gray-50 rounded-lg p-8">
              <h3 className="text-lg font-bold mb-2">Qulay</h3>
              <p className="text-gray-600">
                Yaqin pickup nuqtalari orqali olib ketish
              </p>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-white mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-4 gap-8 mb-8">
            <div>
              <h4 className="font-bold mb-4">Bittada</h4>
              <p className="text-gray-400">Qulaylik. Bittada.</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">Sotuvchilar</h4>
              <ul className="text-gray-400 space-y-2">
                <li><Link href="/seller" className="hover:text-white">Sotuvchi kabinetiga kirish</Link></li>
                <li><Link href="/seller/register" className="hover:text-white">Ro'yxatdan o'tish</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Harajat</h4>
              <ul className="text-gray-400 space-y-2">
                <li><a href="#" className="hover:text-white">Savollar</a></li>
                <li><a href="#" className="hover:text-white">Yordamcha</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">Yuridik</h4>
              <ul className="text-gray-400 space-y-2">
                <li><a href="#" className="hover:text-white">Shartlar</a></li>
                <li><a href="#" className="hover:text-white">Maxfiylik</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-gray-400">
            <p>&copy; 2024 BITTADA. Barcha huquqlar himoya qilingan.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
