import { db } from "@/db";
import { complaints } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);
    if (!payload) {
      return Response.json(
        { error: "Invalid token" },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status") || "open";

    let complaintsList;

    if (payload.role === "customer") {
      // Get customer's complaints
      complaintsList = await db
        .select()
        .from(complaints)
        .where(eq(complaints.customer_id, payload.userId));
    } else if (payload.role === "seller") {
      // Get complaints against seller's products
      complaintsList = await db
        .select()
        .from(complaints)
        .where(eq(complaints.seller_id, payload.userId));
    } else if (payload.role === "admin") {
      // Get all complaints, optionally filtered by status
      if (status !== "all") {
        complaintsList = await db
          .select()
          .from(complaints)
          .where(eq(complaints.status, status));
      } else {
        complaintsList = await db.select().from(complaints);
      }
    } else {
      return Response.json(
        { error: "Unauthorized" },
        { status: 403 }
      );
    }

    return Response.json({
      complaints: complaintsList,
      total: complaintsList.length,
    });
  } catch (error) {
    console.error("List complaints error:", error);
    return Response.json(
      { error: "Failed to fetch complaints" },
      { status: 500 }
    );
  }
}
