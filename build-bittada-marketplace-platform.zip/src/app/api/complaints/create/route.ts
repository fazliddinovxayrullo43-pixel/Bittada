import { db } from "@/db";
import { complaints, orders, orderItems, sellerProfiles } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { generateComplaintNumber } from "@/lib/utils";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);
    if (!payload || payload.role !== "customer") {
      return Response.json(
        { error: "Only customers can file complaints" },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { order_id, product_id, reason, description } = body;

    if (!order_id || !reason || !description) {
      return Response.json(
        { error: "Order ID, reason, and description required" },
        { status: 400 }
      );
    }

    // Verify order belongs to customer
    const orderData = await db
      .select()
      .from(orders)
      .where(eq(orders.id, order_id))
      .limit(1);

    if (orderData.length === 0 || orderData[0].customer_id !== payload.userId) {
      return Response.json(
        { error: "Order not found or not authorized" },
        { status: 404 }
      );
    }

    // Get seller for this order
    let seller_id: string | null = null;
    if (product_id) {
      const item = await db
        .select()
        .from(orderItems)
        .where(eq(orderItems.product_id, product_id))
        .limit(1);

      if (item.length > 0) {
        seller_id = item[0].seller_id;
      }
    } else {
      // Get first seller from order
      const firstItem = await db
        .select()
        .from(orderItems)
        .where(eq(orderItems.order_id, order_id))
        .limit(1);

      if (firstItem.length > 0) {
        seller_id = firstItem[0].seller_id;
      }
    }

    if (!seller_id) {
      return Response.json(
        { error: "Could not find seller" },
        { status: 400 }
      );
    }

    // Create complaint
    const complaintNumber = generateComplaintNumber();
    const newComplaint = await db
      .insert(complaints)
      .values({
        complaint_number: complaintNumber,
        order_id,
        product_id,
        customer_id: payload.userId,
        seller_id,
        reason,
        description,
        status: "open",
      })
      .returning();

    return Response.json({
      success: true,
      complaint: newComplaint[0],
      message: "Complaint filed successfully",
    });
  } catch (error) {
    console.error("Create complaint error:", error);
    return Response.json(
      { error: "Failed to file complaint" },
      { status: 500 }
    );
  }
}
