import { db } from "@/db";
import { sellerProfiles, products, orders, orderItems } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);
    if (!payload || payload.role !== "seller") {
      return Response.json(
        { error: "Only sellers can access stats" },
        { status: 403 }
      );
    }

    // Get seller profile
    const seller = await db
      .select()
      .from(sellerProfiles)
      .where(eq(sellerProfiles.user_id, payload.userId))
      .limit(1);

    if (seller.length === 0) {
      return Response.json(
        { error: "Seller profile not found" },
        { status: 404 }
      );
    }

    const seller_id = seller[0].id;

    // Get products count
    const sellerProducts = await db
      .select()
      .from(products)
      .where(eq(products.seller_id, seller_id));

    const totalProducts = sellerProducts.length;
    const activeProducts = sellerProducts.filter(
      (p) => p.status === "approved" && p.stock_quantity > 0
    ).length;

    // Get orders
    const sellerOrders = await db
      .select()
      .from(orderItems)
      .where(eq(orderItems.seller_id, seller_id));

    const totalOrders = sellerOrders.length;
    const pendingOrders = 0; // Would calculate from order items with status

    // Calculate revenue
    const revenue = sellerOrders.reduce(
      (sum, item) => sum + parseFloat(item.subtotal || "0"),
      0
    );

    return Response.json({
      stats: {
        total_products: totalProducts,
        active_products: activeProducts,
        total_orders: totalOrders,
        pending_orders: pendingOrders,
        revenue: revenue.toString(),
        verification_status: seller[0].verification_status,
        rating: seller[0].rating,
      },
    });
  } catch (error) {
    console.error("Get seller stats error:", error);
    return Response.json(
      { error: "Failed to fetch statistics" },
      { status: 500 }
    );
  }
}
