import { db } from "@/db";
import {
  sellerProfiles,
  orderItems,
  orders,
  products,
  pickupPoints,
} from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);
    if (!payload || payload.role !== "seller") {
      return Response.json(
        { error: "Only sellers can access this" },
        { status: 403 }
      );
    }

    // Get seller profile
    const seller = await db
      .select()
      .from(sellerProfiles)
      .where(eq(sellerProfiles.user_id, payload.userId))
      .limit(1);

    if (seller.length === 0) {
      return Response.json(
        { error: "Seller profile not found" },
        { status: 404 }
      );
    }

    // Get orders for this seller's products
    const sellerOrders = await db
      .select()
      .from(orderItems)
      .where(eq(orderItems.seller_id, seller[0].id));

    // Get full order details for each
    const ordersWithDetails = await Promise.all(
      sellerOrders.map(async (item) => {
        const order = await db
          .select()
          .from(orders)
          .where(eq(orders.id, item.order_id))
          .limit(1);

        const product = await db
          .select()
          .from(products)
          .where(eq(products.id, item.product_id))
          .limit(1);

        const pickupPoint = await db
          .select()
          .from(pickupPoints)
          .where(eq(pickupPoints.id, order[0].pickup_point_id))
          .limit(1);

        return {
          order_item: item,
          order: order[0],
          product: product[0],
          pickup_point: pickupPoint[0],
        };
      })
    );

    return Response.json({
      orders: ordersWithDetails,
      total: ordersWithDetails.length,
    });
  } catch (error) {
    console.error("Seller orders error:", error);
    return Response.json(
      { error: "Failed to fetch orders" },
      { status: 500 }
    );
  }
}
