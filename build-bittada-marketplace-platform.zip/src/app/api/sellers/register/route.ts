import { db } from "@/db";
import { users, sellerProfiles } from "@/db/schema";
import { hashPassword, generateToken, parseAuthHeader, verifyToken } from "@/lib/auth";
import { isValidEmail, isValidPhoneNumber } from "@/lib/utils";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);
    if (!payload) {
      return Response.json(
        { error: "Invalid token" },
        { status: 401 }
      );
    }

    // Check if user already has seller profile
    const existing = await db
      .select()
      .from(sellerProfiles)
      .where(eq(sellerProfiles.user_id, payload.userId))
      .limit(1);

    if (existing.length > 0) {
      return Response.json(
        { error: "User already has seller profile" },
        { status: 409 }
      );
    }

    const body = await req.json();
    const {
      business_name,
      seller_type,
      address,
      city,
      phone,
      description,
    } = body;

    // Validation
    if (!business_name || !seller_type || !address || !city || !phone) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }

    if (!["individual", "business", "company"].includes(seller_type)) {
      return Response.json(
        { error: "Invalid seller type" },
        { status: 400 }
      );
    }

    // Create seller profile
    const newProfile = await db
      .insert(sellerProfiles)
      .values({
        user_id: payload.userId,
        business_name,
        seller_type,
        address,
        city,
        phone,
        description,
        verification_status: "pending",
      })
      .returning();

    return Response.json({
      success: true,
      profile: newProfile[0],
      message: "Seller profile created. Awaiting admin verification.",
    });
  } catch (error) {
    console.error("Seller registration error:", error);
    return Response.json(
      { error: "Registration failed" },
      { status: 500 }
    );
  }
}
