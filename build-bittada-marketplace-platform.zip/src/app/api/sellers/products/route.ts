import { db } from "@/db";
import { products, sellerProfiles, productImages } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);
    if (!payload || payload.role !== "seller") {
      return Response.json(
        { error: "Only sellers can access this" },
        { status: 403 }
      );
    }

    // Get seller profile
    const sellerProfile = await db
      .select()
      .from(sellerProfiles)
      .where(eq(sellerProfiles.user_id, payload.userId))
      .limit(1);

    if (sellerProfile.length === 0) {
      return Response.json(
        { error: "Seller profile not found" },
        { status: 404 }
      );
    }

    // Get seller's products
    const sellerProducts = await db
      .select()
      .from(products)
      .where(eq(products.seller_id, sellerProfile[0].id));

    // Get images for each product
    const productsWithImages = await Promise.all(
      sellerProducts.map(async (product) => {
        const images = await db
          .select()
          .from(productImages)
          .where(eq(productImages.product_id, product.id));

        return {
          ...product,
          images,
        };
      })
    );

    return Response.json({
      products: productsWithImages,
    });
  } catch (error) {
    console.error("Seller products error:", error);
    return Response.json(
      { error: "Failed to fetch products" },
      { status: 500 }
    );
  }
}
