import { db } from "@/db";
import { sellerProfiles } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);
    if (!payload) {
      return Response.json(
        { error: "Invalid token" },
        { status: 401 }
      );
    }

    const sellerProfile = await db
      .select()
      .from(sellerProfiles)
      .where(eq(sellerProfiles.user_id, payload.userId))
      .limit(1);

    if (sellerProfile.length === 0) {
      return Response.json(
        { error: "Seller profile not found" },
        { status: 404 }
      );
    }

    return Response.json({
      seller: sellerProfile[0],
    });
  } catch (error) {
    console.error("Seller profile fetch error:", error);
    return Response.json(
      { error: "Failed to fetch seller profile" },
      { status: 500 }
    );
  }
}
