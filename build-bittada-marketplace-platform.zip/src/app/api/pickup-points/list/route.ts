import { db } from "@/db";
import { pickupPoints } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const city = searchParams.get("city");

    let query = db.select().from(pickupPoints).where(eq(pickupPoints.status, "active"));

    let points;
    if (city) {
      points = await db
        .select()
        .from(pickupPoints)
        .where(eq(pickupPoints.city, city));
    } else {
      points = await db
        .select()
        .from(pickupPoints)
        .where(eq(pickupPoints.status, "active"));
    }

    return Response.json({
      points,
      total: points.length,
    });
  } catch (error) {
    console.error("Pickup points error:", error);
    return Response.json(
      { error: "Failed to fetch pickup points" },
      { status: 500 }
    );
  }
}
