import { db } from "@/db";
import { reviews } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const product_id = searchParams.get("product_id");

    if (!product_id) {
      return Response.json(
        { error: "Product ID required" },
        { status: 400 }
      );
    }

    const productReviews = await db
      .select()
      .from(reviews)
      .where(eq(reviews.product_id, product_id));

    // Calculate average rating
    const avgRating =
      productReviews.length > 0
        ? (
            productReviews.reduce((sum, r) => sum + Number(r.rating), 0) /
            productReviews.length
          ).toFixed(2)
        : 0;

    return Response.json({
      reviews: productReviews,
      average_rating: avgRating,
      total_reviews: productReviews.length,
      rating_distribution: {
        5: productReviews.filter((r) => r.rating === 5).length,
        4: productReviews.filter((r) => r.rating === 4).length,
        3: productReviews.filter((r) => r.rating === 3).length,
        2: productReviews.filter((r) => r.rating === 2).length,
        1: productReviews.filter((r) => r.rating === 1).length,
      },
    });
  } catch (error) {
    console.error("List reviews error:", error);
    return Response.json(
      { error: "Failed to fetch reviews" },
      { status: 500 }
    );
  }
}
