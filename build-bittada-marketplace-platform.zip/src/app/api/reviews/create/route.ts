import { db } from "@/db";
import { reviews, orderItems, orders } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq, and } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);
    if (!payload || payload.role !== "customer") {
      return Response.json(
        { error: "Only customers can leave reviews" },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { product_id, order_item_id, rating, title, text } = body;

    if (!product_id || !order_item_id || !rating || rating < 1 || rating > 5) {
      return Response.json(
        { error: "Valid product, order item, and rating (1-5) required" },
        { status: 400 }
      );
    }

    // Verify customer purchased this product
    const orderItem = await db
      .select()
      .from(orderItems)
      .where(eq(orderItems.id, order_item_id))
      .limit(1);

    if (orderItem.length === 0) {
      return Response.json(
        { error: "Order item not found" },
        { status: 404 }
      );
    }

    // Verify order belongs to customer
    const order = await db
      .select()
      .from(orders)
      .where(
        and(
          eq(orders.id, orderItem[0].order_id),
          eq(orders.customer_id, payload.userId)
        )
      )
      .limit(1);

    if (order.length === 0) {
      return Response.json(
        { error: "Not authorized to review this product" },
        { status: 403 }
      );
    }

    // Check if review already exists
    const existing = await db
      .select()
      .from(reviews)
      .where(
        and(
          eq(reviews.product_id, product_id),
          eq(reviews.customer_id, payload.userId)
        )
      )
      .limit(1);

    if (existing.length > 0) {
      return Response.json(
        { error: "You have already reviewed this product" },
        { status: 400 }
      );
    }

    // Create review
    const newReview = await db
      .insert(reviews)
      .values({
        product_id,
        order_item_id,
        customer_id: payload.userId,
        rating: rating as any,
        title,
        text,
        is_verified_purchase: true,
      })
      .returning();

    return Response.json({
      success: true,
      review: newReview[0],
    });
  } catch (error) {
    console.error("Create review error:", error);
    return Response.json(
      { error: "Failed to create review" },
      { status: 500 }
    );
  }
}
