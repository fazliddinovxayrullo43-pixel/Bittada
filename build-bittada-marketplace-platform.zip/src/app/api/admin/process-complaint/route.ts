import { db } from "@/db";
import { complaints, refunds } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { generateRefundNumber } from "@/lib/utils";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);
    if (!payload || payload.role !== "admin") {
      return Response.json(
        { error: "Only admins can process complaints" },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { complaint_id, resolution_type, admin_notes } = body;

    if (!complaint_id || !resolution_type) {
      return Response.json(
        { error: "Complaint ID and resolution type required" },
        { status: 400 }
      );
    }

    // Get complaint
    const complaintData = await db
      .select()
      .from(complaints)
      .where(eq(complaints.id, complaint_id))
      .limit(1);

    if (complaintData.length === 0) {
      return Response.json(
        { error: "Complaint not found" },
        { status: 404 }
      );
    }

    const complaint = complaintData[0];

    // Update complaint
    const updated = await db
      .update(complaints)
      .set({
        status: "resolved",
        resolution_type,
        resolved_at: new Date(),
        admin_notes,
      })
      .where(eq(complaints.id, complaint_id))
      .returning();

    // If resolution involves refund, create refund record
    if (resolution_type === "partial_refund" || resolution_type === "full_refund") {
      // In real implementation, would calculate actual refund amount from order
      const refundAmount = "0"; // Placeholder

      const refundNumber = generateRefundNumber();
      await db.insert(refunds).values({
        refund_number: refundNumber,
        order_id: complaint.order_id,
        complaint_id: complaint.id,
        customer_id: complaint.customer_id,
        amount: refundAmount,
        reason: `Complaint ${complaint.complaint_number}: ${complaint.reason}`,
        status: "approved",
        processed_by_id: payload.userId,
        processed_at: new Date(),
      });
    }

    return Response.json({
      success: true,
      complaint: updated[0],
      message: "Complaint processed successfully",
    });
  } catch (error) {
    console.error("Process complaint error:", error);
    return Response.json(
      { error: "Failed to process complaint" },
      { status: 500 }
    );
  }
}
