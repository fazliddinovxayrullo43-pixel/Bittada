import { db } from "@/db";
import { products, productImages, sellerProfiles } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);
    if (!payload || payload.role !== "admin") {
      return Response.json(
        { error: "Only admins can access this" },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status") || "pending_review";

    let productsQuery;
    if (status === "all") {
      productsQuery = await db.select().from(products);
    } else {
      productsQuery = await db
        .select()
        .from(products)
        .where(eq(products.status, status));
    }

    // Get seller info and images for each product
    const productsWithDetails = await Promise.all(
      productsQuery.map(async (product) => {
        const seller = await db
          .select()
          .from(sellerProfiles)
          .where(eq(sellerProfiles.id, product.seller_id))
          .limit(1);

        const images = await db
          .select()
          .from(productImages)
          .where(eq(productImages.product_id, product.id));

        return {
          ...product,
          seller: seller[0],
          images,
        };
      })
    );

    return Response.json({
      products: productsWithDetails,
      total: productsWithDetails.length,
    });
  } catch (error) {
    console.error("Admin products error:", error);
    return Response.json(
      { error: "Failed to fetch products" },
      { status: 500 }
    );
  }
}
