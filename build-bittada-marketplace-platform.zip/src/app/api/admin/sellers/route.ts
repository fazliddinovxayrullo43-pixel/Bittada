import { db } from "@/db";
import { sellerProfiles, users } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);
    if (!payload || payload.role !== "admin") {
      return Response.json(
        { error: "Only admins can access this" },
        { status: 403 }
      );
    }

    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status") || "pending";

    let sellers;
    if (status === "all") {
      sellers = await db.select().from(sellerProfiles);
    } else {
      sellers = await db
        .select()
        .from(sellerProfiles)
        .where(eq(sellerProfiles.verification_status, status));
    }

    return Response.json({
      sellers,
      total: sellers.length,
    });
  } catch (error) {
    console.error("Admin sellers error:", error);
    return Response.json(
      { error: "Failed to fetch sellers" },
      { status: 500 }
    );
  }
}
