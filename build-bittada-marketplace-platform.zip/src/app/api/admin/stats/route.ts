import { db } from "@/db";
import { users, sellerProfiles, products, orders, orderItems, complaints, refunds } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);
    if (!payload || payload.role !== "admin") {
      return Response.json(
        { error: "Only admins can access platform stats" },
        { status: 403 }
      );
    }

    // Count users
    const allUsers = await db.select().from(users);
    const customerCount = allUsers.filter((u) => u.role === "customer").length;

    // Count sellers
    const allSellers = await db.select().from(sellerProfiles);
    const approvedSellers = allSellers.filter(
      (s) => s.verification_status === "approved"
    ).length;
    const pendingSellers = allSellers.filter(
      (s) => s.verification_status === "pending"
    ).length;

    // Count products
    const allProducts = await db.select().from(products);
    const approvedProducts = allProducts.filter(
      (p) => p.status === "approved"
    ).length;
    const pendingProducts = allProducts.filter(
      (p) => p.status === "pending_review"
    ).length;

    // Count orders
    const allOrders = await db.select().from(orders);
    const totalRevenue = allOrders.reduce(
      (sum, o) => sum + parseFloat(o.total || "0"),
      0
    );

    // Count complaints
    const allComplaints = await db.select().from(complaints);
    const openComplaints = allComplaints.filter(
      (c) => c.status === "open"
    ).length;

    // Count refunds
    const allRefunds = await db.select().from(refunds);
    const totalRefunded = allRefunds.reduce(
      (sum, r) => sum + parseFloat(r.amount || "0"),
      0
    );

    return Response.json({
      stats: {
        users: {
          total: allUsers.length,
          customers: customerCount,
        },
        sellers: {
          total: allSellers.length,
          approved: approvedSellers,
          pending: pendingSellers,
        },
        products: {
          total: allProducts.length,
          approved: approvedProducts,
          pending: pendingProducts,
        },
        orders: {
          total: allOrders.length,
          revenue: totalRevenue.toString(),
        },
        complaints: {
          total: allComplaints.length,
          open: openComplaints,
        },
        refunds: {
          total: allRefunds.length,
          amount: totalRefunded.toString(),
        },
      },
    });
  } catch (error) {
    console.error("Get admin stats error:", error);
    return Response.json(
      { error: "Failed to fetch statistics" },
      { status: 500 }
    );
  }
}
