import { db } from "@/db";
import { products, adminActions, notifications } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const payload = verifyToken(token);
    if (!payload || payload.role !== "admin") {
      return Response.json(
        { error: "Only admins can review products" },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { product_id, approved, reason } = body;

    if (!product_id || typeof approved !== "boolean") {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }

    const newStatus = approved ? "approved" : "rejected";

    const updated = await db
      .update(products)
      .set({
        status: newStatus,
        rejected_reason: !approved ? reason : undefined,
      })
      .where(eq(products.id, product_id))
      .returning();

    if (updated.length === 0) {
      return Response.json(
        { error: "Product not found" },
        { status: 404 }
      );
    }

    const product = updated[0];

    // Log admin action
    await db.insert(adminActions).values({
      admin_id: payload.userId,
      action_type: approved ? "approve_product" : "reject_product",
      target_type: "product",
      target_id: product_id,
      details: { productName: product.name, reason },
    });

    // Notify seller
    await db.insert(notifications).values({
      user_id: product.seller_id, // This should actually be the seller's user_id
      type: approved ? "product_approved" : "product_rejected",
      title: approved ? "Product Approved" : "Product Rejected",
      message: `Your product "${product.name}" has been ${approved ? "approved" : "rejected"}${!approved ? `: ${reason}` : ""}`,
    });

    return Response.json({
      success: true,
      product: updated[0],
    });
  } catch (error) {
    console.error("Approve product error:", error);
    return Response.json(
      { error: "Failed to review product" },
      { status: 500 }
    );
  }
}
