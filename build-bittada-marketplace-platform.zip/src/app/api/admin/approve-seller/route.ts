import { db } from "@/db";
import { sellerProfiles, adminActions, users } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const payload = verifyToken(token);
    if (!payload || payload.role !== "admin") {
      return Response.json(
        { error: "Only admins can approve sellers" },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { seller_id, approved } = body;

    if (!seller_id || typeof approved !== "boolean") {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }

    const newStatus = approved ? "approved" : "rejected";

    const updated = await db
      .update(sellerProfiles)
      .set({
        verification_status: newStatus,
        verified_at: approved ? new Date() : undefined,
      })
      .where(eq(sellerProfiles.id, seller_id))
      .returning();

    if (updated.length === 0) {
      return Response.json(
        { error: "Seller not found" },
        { status: 404 }
      );
    }

    // Log admin action
    await db.insert(adminActions).values({
      admin_id: payload.userId,
      action_type: approved ? "approve_seller" : "reject_seller",
      target_type: "seller",
      target_id: seller_id,
      details: { reason: approved ? "Seller approved" : "Seller rejected" },
    });

    return Response.json({
      success: true,
      seller: updated[0],
    });
  } catch (error) {
    console.error("Approve seller error:", error);
    return Response.json(
      { error: "Failed to process seller" },
      { status: 500 }
    );
  }
}
