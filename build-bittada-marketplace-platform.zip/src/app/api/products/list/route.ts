import { db } from "@/db";
import { products, productImages } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "20");
    const offset = (page - 1) * limit;

    // Get approved products only
    const approvedProducts = await db
      .select()
      .from(products)
      .where(eq(products.status, "approved"))
      .limit(limit)
      .offset(offset);

    // Get images for each product
    const productsWithImages = await Promise.all(
      approvedProducts.map(async (product) => {
        const images = await db
          .select()
          .from(productImages)
          .where(eq(productImages.product_id, product.id));

        return {
          ...product,
          images,
        };
      })
    );

    return Response.json({
      products: productsWithImages,
      page,
      limit,
      total: productsWithImages.length,
    });
  } catch (error) {
    console.error("Products list error:", error);
    return Response.json(
      { error: "Failed to fetch products" },
      { status: 500 }
    );
  }
}
