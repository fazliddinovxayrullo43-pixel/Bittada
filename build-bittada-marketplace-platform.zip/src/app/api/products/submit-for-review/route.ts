import { db } from "@/db";
import { products, sellerProfiles } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq, and } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const payload = verifyToken(token);
    if (!payload || payload.role !== "seller") {
      return Response.json({ error: "Only sellers can submit products" }, { status: 403 });
    }

    const body = await req.json();
    const { product_id } = body;

    if (!product_id) {
      return Response.json(
        { error: "Product ID required" },
        { status: 400 }
      );
    }

    // Get seller profile
    const sellerProfile = await db
      .select()
      .from(sellerProfiles)
      .where(eq(sellerProfiles.user_id, payload.userId))
      .limit(1);

    if (sellerProfile.length === 0) {
      return Response.json(
        { error: "Seller profile not found" },
        { status: 404 }
      );
    }

    // Get product and verify ownership
    const product = await db
      .select()
      .from(products)
      .where(
        and(
          eq(products.id, product_id),
          eq(products.seller_id, sellerProfile[0].id)
        )
      )
      .limit(1);

    if (product.length === 0) {
      return Response.json(
        { error: "Product not found" },
        { status: 404 }
      );
    }

    if (product[0].status !== "draft") {
      return Response.json(
        { error: "Only draft products can be submitted" },
        { status: 400 }
      );
    }

    // Update product status
    const updated = await db
      .update(products)
      .set({ status: "pending_review" })
      .where(eq(products.id, product_id))
      .returning();

    return Response.json({
      success: true,
      product: updated[0],
      message: "Product submitted for review",
    });
  } catch (error) {
    console.error("Submit for review error:", error);
    return Response.json(
      { error: "Failed to submit product" },
      { status: 500 }
    );
  }
}
