import { db } from "@/db";
import { products, sellerProfiles } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const payload = verifyToken(token);
    if (!payload || payload.role !== "seller") {
      return Response.json({ error: "Only sellers can create products" }, { status: 403 });
    }

    // Get seller profile
    const sellerProfile = await db
      .select()
      .from(sellerProfiles)
      .where(eq(sellerProfiles.user_id, payload.userId))
      .limit(1);

    if (sellerProfile.length === 0) {
      return Response.json(
        { error: "Seller profile not found" },
        { status: 404 }
      );
    }

    if (sellerProfile[0].verification_status !== "approved") {
      return Response.json(
        { error: "Seller account must be verified first" },
        { status: 403 }
      );
    }

    const body = await req.json();
    const {
      name,
      description,
      price,
      category_id,
      sku,
      stock_quantity,
      weight,
      dimensions,
      currency = "UZS",
    } = body;

    // Validation
    if (!name || !price) {
      return Response.json(
        { error: "Name and price are required" },
        { status: 400 }
      );
    }

    if (typeof price !== "number" || price <= 0) {
      return Response.json(
        { error: "Price must be a positive number" },
        { status: 400 }
      );
    }

    // Create product
    const newProduct = await db
      .insert(products)
      .values({
        seller_id: sellerProfile[0].id,
        name,
        description,
        price: price.toString(),
        category_id,
        sku,
        stock_quantity: stock_quantity || 0,
        weight,
        dimensions,
        currency,
        status: "draft", // Starts as draft
      })
      .returning();

    return Response.json({
      success: true,
      product: newProduct[0],
    });
  } catch (error) {
    console.error("Product creation error:", error);
    return Response.json(
      { error: "Product creation failed" },
      { status: 500 }
    );
  }
}
