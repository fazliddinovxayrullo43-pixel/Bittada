import { db } from "@/db";
import { users } from "@/db/schema";
import { hashPassword, generateToken } from "@/lib/auth";
import { isValidEmail, isValidPhoneNumber } from "@/lib/utils";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { email, password, full_name, phone, role = "customer" } = body;

    // Validation
    if (!email || !password || !full_name || !phone) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 }
      );
    }

    if (!isValidEmail(email)) {
      return Response.json(
        { error: "Invalid email format" },
        { status: 400 }
      );
    }

    if (!isValidPhoneNumber(phone)) {
      return Response.json(
        { error: "Invalid phone number format" },
        { status: 400 }
      );
    }

    if (password.length < 6) {
      return Response.json(
        { error: "Password must be at least 6 characters" },
        { status: 400 }
      );
    }

    // Check if user exists
    const existingUser = await db
      .select()
      .from(users)
      .where(eq(users.email, email))
      .limit(1);

    if (existingUser.length > 0) {
      return Response.json(
        { error: "Email already registered" },
        { status: 409 }
      );
    }

    // Check if phone exists
    const existingPhone = await db
      .select()
      .from(users)
      .where(eq(users.phone, phone))
      .limit(1);

    if (existingPhone.length > 0) {
      return Response.json(
        { error: "Phone number already registered" },
        { status: 409 }
      );
    }

    // Hash password
    const passwordHash = await hashPassword(password);

    // Create user
    const newUser = await db
      .insert(users)
      .values({
        email,
        password_hash: passwordHash,
        full_name,
        phone,
        role: role === "seller" ? "seller" : "customer",
      })
      .returning();

    const user = newUser[0];

    // Generate token
    const token = generateToken({
      userId: user.id,
      email: user.email,
      role: user.role,
    });

    return Response.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        full_name: user.full_name,
        phone: user.phone,
        role: user.role,
      },
      token,
    });
  } catch (error) {
    console.error("Registration error:", error);
    return Response.json(
      { error: "Registration failed" },
      { status: 500 }
    );
  }
}
