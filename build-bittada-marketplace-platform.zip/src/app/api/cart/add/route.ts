import { db } from "@/db";
import { cart, cartItems, products } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);
    if (!payload || payload.role !== "customer") {
      return Response.json(
        { error: "Only customers can add to cart" },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { product_id, quantity = 1 } = body;

    if (!product_id || quantity < 1) {
      return Response.json(
        { error: "Invalid product or quantity" },
        { status: 400 }
      );
    }

    // Get product
    const productResult = await db
      .select()
      .from(products)
      .where(eq(products.id, product_id))
      .limit(1);

    if (productResult.length === 0) {
      return Response.json(
        { error: "Product not found" },
        { status: 404 }
      );
    }

    const product = productResult[0];

    // Check stock
    if (product.stock_quantity < quantity) {
      return Response.json(
        { error: "Not enough stock" },
        { status: 400 }
      );
    }

    // Check or create cart
    let userCart = await db
      .select()
      .from(cart)
      .where(eq(cart.customer_id, payload.userId))
      .limit(1);

    if (userCart.length === 0) {
      // Create new cart
      const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days
      const newCart = await db
        .insert(cart)
        .values({
          customer_id: payload.userId,
          expires_at: expiresAt,
        })
        .returning();
      userCart = newCart;
    }

    // Check if product already in cart
    const existingItem = await db
      .select()
      .from(cartItems)
      .where(eq(cartItems.product_id, product_id))
      .limit(1);

    if (existingItem.length > 0) {
      // Update quantity
      const newQuantity = existingItem[0].quantity + quantity;
      
      if (product.stock_quantity < newQuantity) {
        return Response.json(
          { error: "Not enough stock for total quantity" },
          { status: 400 }
        );
      }

      const updated = await db
        .update(cartItems)
        .set({ quantity: newQuantity })
        .where(eq(cartItems.id, existingItem[0].id))
        .returning();

      return Response.json({
        success: true,
        item: updated[0],
      });
    }

    // Add new item
    const newItem = await db
      .insert(cartItems)
      .values({
        cart_id: userCart[0].id,
        product_id,
        quantity,
        price_at_addition: product.price,
      })
      .returning();

    return Response.json({
      success: true,
      item: newItem[0],
    });
  } catch (error) {
    console.error("Add to cart error:", error);
    return Response.json(
      { error: "Failed to add to cart" },
      { status: 500 }
    );
  }
}
