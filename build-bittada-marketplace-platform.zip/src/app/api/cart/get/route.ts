import { db } from "@/db";
import { cart, cartItems, products } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);
    if (!payload || payload.role !== "customer") {
      return Response.json(
        { error: "Only customers can access cart" },
        { status: 403 }
      );
    }

    // Get customer's cart
    const userCart = await db
      .select()
      .from(cart)
      .where(eq(cart.customer_id, payload.userId))
      .limit(1);

    if (userCart.length === 0) {
      return Response.json({
        cart: null,
        items: [],
        subtotal: 0,
        total: 0,
      });
    }

    // Get cart items
    const items = await db
      .select()
      .from(cartItems)
      .where(eq(cartItems.cart_id, userCart[0].id));

    // Get product details for each item
    const itemsWithDetails = await Promise.all(
      items.map(async (item) => {
        const productData = await db
          .select()
          .from(products)
          .where(eq(products.id, item.product_id))
          .limit(1);

        const product = productData[0];

        return {
          ...item,
          product: {
            id: product.id,
            name: product.name,
            price: product.price,
            image_url: null, // Would fetch from product_images
          },
          line_total: parseFloat(item.price_at_addition) * item.quantity,
        };
      })
    );

    // Calculate totals
    const subtotal = itemsWithDetails.reduce(
      (sum, item) => sum + item.line_total,
      0
    );

    return Response.json({
      cart: userCart[0],
      items: itemsWithDetails,
      subtotal,
      delivery_fee: 0,
      discount: 0,
      total: subtotal,
      item_count: itemsWithDetails.length,
    });
  } catch (error) {
    console.error("Get cart error:", error);
    return Response.json(
      { error: "Failed to fetch cart" },
      { status: 500 }
    );
  }
}
