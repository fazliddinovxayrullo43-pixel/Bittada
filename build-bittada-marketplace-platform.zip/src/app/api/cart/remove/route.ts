import { db } from "@/db";
import { cartItems, cart } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq, and } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);
    if (!payload || payload.role !== "customer") {
      return Response.json(
        { error: "Only customers can modify cart" },
        { status: 403 }
      );
    }

    const body = await req.json();
    const { item_id } = body;

    if (!item_id) {
      return Response.json(
        { error: "Item ID required" },
        { status: 400 }
      );
    }

    // Verify item belongs to user's cart
    const userCart = await db
      .select()
      .from(cart)
      .where(eq(cart.customer_id, payload.userId))
      .limit(1);

    if (userCart.length === 0) {
      return Response.json(
        { error: "Cart not found" },
        { status: 404 }
      );
    }

    // Delete item
    const deleted = await db
      .delete(cartItems)
      .where(
        and(
          eq(cartItems.id, item_id),
          eq(cartItems.cart_id, userCart[0].id)
        )
      )
      .returning();

    if (deleted.length === 0) {
      return Response.json(
        { error: "Item not found in cart" },
        { status: 404 }
      );
    }

    return Response.json({
      success: true,
      message: "Item removed from cart",
    });
  } catch (error) {
    console.error("Remove from cart error:", error);
    return Response.json(
      { error: "Failed to remove item" },
      { status: 500 }
    );
  }
}
