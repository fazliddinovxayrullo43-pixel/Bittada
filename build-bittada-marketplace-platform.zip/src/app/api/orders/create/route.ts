import { db } from "@/db";
import {
  orders,
  orderItems,
  orderStatusHistory,
  pickupCodes,
  cartItems,
  cart,
  products,
} from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { generateOrderNumber, generatePickupCode } from "@/lib/utils";
import { eq, and, inArray } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const payload = verifyToken(token);
    if (!payload || payload.role !== "customer") {
      return Response.json(
        { error: "Only customers can create orders" },
        { status: 403 }
      );
    }

    const body = await req.json();
    const {
      pickup_point_id,
      payment_method = "cash_on_delivery",
      customer_notes,
    } = body;

    if (!pickup_point_id) {
      return Response.json(
        { error: "Pickup point required" },
        { status: 400 }
      );
    }

    // Get customer's cart
    const userCart = await db
      .select()
      .from(cart)
      .where(eq(cart.customer_id, payload.userId))
      .limit(1);

    if (userCart.length === 0) {
      return Response.json({ error: "Cart not found" }, { status: 404 });
    }

    // Get cart items with product details
    const items = await db
      .select()
      .from(cartItems)
      .where(eq(cartItems.cart_id, userCart[0].id));

    if (items.length === 0) {
      return Response.json(
        { error: "Cart is empty" },
        { status: 400 }
      );
    }

    // Fetch products and validate stock
    const productIds = items.map((item) => item.product_id);
    const productsData = await db
      .select()
      .from(products)
      .where(inArray(products.id, productIds));

    const productMap = new Map(productsData.map((p) => [p.id, p]));

    let subtotal = 0;
    const orderItemsData = [];

    // Validate stock and calculate subtotal
    for (const item of items) {
      const product = productMap.get(item.product_id);

      if (!product) {
        return Response.json(
          { error: `Product ${item.product_id} not found` },
          { status: 404 }
        );
      }

      if (product.stock_quantity < item.quantity) {
        return Response.json(
          { error: `Not enough stock for ${product.name}` },
          { status: 400 }
        );
      }

      const itemSubtotal = parseFloat(item.price_at_addition) * item.quantity;
      subtotal += itemSubtotal;

      orderItemsData.push({
        product_id: item.product_id,
        seller_id: product.seller_id,
        product_name: product.name,
        quantity: item.quantity,
        price_per_unit: item.price_at_addition,
        subtotal: itemSubtotal.toString(),
      });
    }

    // Generate unique pickup code
    let pickupCode = "";
    let attempts = 0;
    while (attempts < 100) {
      const code = generatePickupCode();
      const existing = await db
        .select()
        .from(pickupCodes)
        .where(eq(pickupCodes.code, code))
        .limit(1);

      if (existing.length === 0) {
        pickupCode = code;
        break;
      }
      attempts++;
    }

    if (!pickupCode) {
      return Response.json(
        { error: "Failed to generate unique pickup code" },
        { status: 500 }
      );
    }

    // Get user phone
    // For now, using placeholder - in real app would fetch from users table
    const userPhone = "+998" + Math.random().toString().slice(2, 11);

    // Create order
    const orderNumber = generateOrderNumber();
    const totalAmount = subtotal.toString();

    const createdOrders = await db
      .insert(orders)
      .values({
        order_number: orderNumber,
        customer_id: payload.userId,
        pickup_point_id,
        pickup_code: pickupCode,
        subtotal: subtotal.toString(),
        delivery_fee: "0",
        discount: "0",
        total: totalAmount,
        payment_method,
        payment_status: "pending",
        currency: "UZS",
        customer_phone: userPhone,
        customer_notes,
        status: "new",
      })
      .returning();

    const order = createdOrders[0];

    // Create order items
    for (const item of orderItemsData) {
      await db.insert(orderItems).values({
        order_id: order.id,
        product_id: item.product_id,
        seller_id: item.seller_id,
        product_name: item.product_name,
        quantity: item.quantity,
        price_per_unit: item.price_per_unit,
        subtotal: item.subtotal,
      });

      // Decrease stock
      const currentProduct = productMap.get(item.product_id)!;
      await db
        .update(products)
        .set({
          stock_quantity: currentProduct.stock_quantity - item.quantity,
        })
        .where(eq(products.id, item.product_id));
    }

    // Create status history entry
    await db.insert(orderStatusHistory).values({
      order_id: order.id,
      from_status: null,
      to_status: "new",
      changed_by_user_id: payload.userId,
    });

    // Clear cart
    await db.delete(cartItems).where(eq(cartItems.cart_id, userCart[0].id));

    return Response.json({
      success: true,
      order: {
        id: order.id,
        order_number: order.order_number,
        pickup_code: order.pickup_code,
        total: order.total,
      },
    });
  } catch (error) {
    console.error("Order creation error:", error);
    return Response.json(
      { error: "Order creation failed" },
      { status: 500 }
    );
  }
}
