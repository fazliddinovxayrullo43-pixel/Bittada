import { db } from "@/db";
import {
  orders,
  orderItems,
  products,
  pickupPoints,
} from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);
    if (!payload) {
      return Response.json(
        { error: "Invalid token" },
        { status: 401 }
      );
    }

    const { searchParams } = new URL(req.url);
    const order_id = searchParams.get("order_id");

    if (order_id) {
      // Get specific order
      const orderData = await db
        .select()
        .from(orders)
        .where(eq(orders.id, order_id))
        .limit(1);

      if (orderData.length === 0) {
        return Response.json(
          { error: "Order not found" },
          { status: 404 }
        );
      }

      const order = orderData[0];

      // Verify authorization
      if (order.customer_id !== payload.userId && payload.role !== "admin") {
        return Response.json(
          { error: "Not authorized to view this order" },
          { status: 403 }
        );
      }

      // Get order items
      const items = await db
        .select()
        .from(orderItems)
        .where(eq(orderItems.order_id, order_id));

      // Get pickup point
      const pickupPoint = await db
        .select()
        .from(pickupPoints)
        .where(eq(pickupPoints.id, order.pickup_point_id))
        .limit(1);

      return Response.json({
        order: {
          ...order,
          items,
          pickup_point: pickupPoint[0],
        },
      });
    } else {
      // Get customer's orders
      if (payload.role !== "customer") {
        return Response.json(
          { error: "Only customers can list their orders" },
          { status: 403 }
        );
      }

      const customerOrders = await db
        .select()
        .from(orders)
        .where(eq(orders.customer_id, payload.userId));

      return Response.json({
        orders: customerOrders,
        total: customerOrders.length,
      });
    }
  } catch (error) {
    console.error("Get order error:", error);
    return Response.json(
      { error: "Failed to fetch order" },
      { status: 500 }
    );
  }
}
