import { db } from "@/db";
import { orders, orderStatusHistory, orderItems, sellerProfiles } from "@/db/schema";
import { parseAuthHeader, verifyToken } from "@/lib/auth";
import { eq, and } from "drizzle-orm";

export async function POST(req: Request) {
  try {
    const authHeader = req.headers.get("authorization");
    const token = parseAuthHeader(authHeader);

    if (!token) {
      return Response.json(
        { error: "Unauthorized" },
        { status: 401 }
      );
    }

    const payload = verifyToken(token);
    if (!payload) {
      return Response.json(
        { error: "Invalid token" },
        { status: 401 }
      );
    }

    const body = await req.json();
    const { order_id, new_status } = body;

    if (!order_id || !new_status) {
      return Response.json(
        { error: "Order ID and status required" },
        { status: 400 }
      );
    }

    // Get order
    const orderData = await db
      .select()
      .from(orders)
      .where(eq(orders.id, order_id))
      .limit(1);

    if (orderData.length === 0) {
      return Response.json(
        { error: "Order not found" },
        { status: 404 }
      );
    }

    const order = orderData[0];

    // Verify authorization
    if (payload.role === "seller") {
      // Seller can only update their own products' orders
      const sellerProfile = await db
        .select()
        .from(sellerProfiles)
        .where(eq(sellerProfiles.user_id, payload.userId))
        .limit(1);

      if (sellerProfile.length === 0) {
        return Response.json(
          { error: "Seller profile not found" },
          { status: 404 }
        );
      }

      // Check if seller has items in this order
      const hasItems = await db
        .select()
        .from(orderItems)
        .where(
          and(
            eq(orderItems.order_id, order_id),
            eq(orderItems.seller_id, sellerProfile[0].id)
          )
        )
        .limit(1);

      if (hasItems.length === 0) {
        return Response.json(
          { error: "Not authorized to update this order" },
          { status: 403 }
        );
      }
    } else if (payload.role !== "admin") {
      return Response.json(
        { error: "Only sellers and admins can update orders" },
        { status: 403 }
      );
    }

    // Update order
    const updated = await db
      .update(orders)
      .set({ status: new_status, updated_at: new Date() })
      .where(eq(orders.id, order_id))
      .returning();

    // Create status history
    await db.insert(orderStatusHistory).values({
      order_id,
      from_status: order.status,
      to_status: new_status,
      changed_by_user_id: payload.userId,
    });

    return Response.json({
      success: true,
      order: updated[0],
    });
  } catch (error) {
    console.error("Update order status error:", error);
    return Response.json(
      { error: "Failed to update order" },
      { status: 500 }
    );
  }
}
