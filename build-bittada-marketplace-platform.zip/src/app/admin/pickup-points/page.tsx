"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function AdminPickupPointsPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const userData = localStorage.getItem("user");

    if (!token || !userData) {
      router.push("/auth/login");
      return;
    }

    const parsedUser = JSON.parse(userData);
    if (parsedUser.role !== "admin") {
      router.push("/");
      return;
    }

    setUser(parsedUser);
  }, [router]);

  if (!user) {
    return <div className="text-center py-8">Yüklanmoqda...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-slate-900 text-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/admin" className="flex items-center gap-2">
              <div className="text-2xl font-bold">BITTADA</div>
              <span className="text-sm text-gray-400">Admin</span>
            </Link>

            <nav className="flex items-center gap-8 text-white">
              <Link href="/admin" className="hover:text-gray-300">
                Bosh sahifa
              </Link>
              <Link href="/admin/pickup-points" className="hover:text-gray-300 font-semibold">
                Pickup Nuqtalari
              </Link>

              <button
                onClick={() => {
                  localStorage.removeItem("token");
                  localStorage.removeItem("user");
                  router.push("/");
                }}
                className="px-4 py-2 text-white hover:bg-slate-800 rounded"
              >
                Chiqish
              </button>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-slate-900">Pickup Nuqtalari</h1>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold">
            Yangi Nuqta
          </button>
        </div>

        {/* Empty State */}
        <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
          <h2 className="text-xl font-bold text-slate-900 mb-2">
            Pickup nuqtasi yo'q
          </h2>
          <p className="text-gray-600 mb-6">
            Pickup nuqtalari qo'shish orqali xaridor buyurtmalarini olish nuqtalarini tanlashi mumkin bo'ladi
          </p>
          <button className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold">
            Birinchi Nuqtani Qo'shish
          </button>
        </div>
      </main>
    </div>
  );
}
