"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function AdminDashboard() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const userData = localStorage.getItem("user");

    if (!token || !userData) {
      router.push("/auth/login");
      return;
    }

    const parsedUser = JSON.parse(userData);
    if (parsedUser.role !== "admin") {
      router.push("/");
      return;
    }

    setUser(parsedUser);
  }, [router]);

  if (!user) {
    return <div className="text-center py-8">Yüklanmoqda...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-slate-900 text-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/admin" className="flex items-center gap-2">
              <div className="text-2xl font-bold">BITTADA</div>
              <span className="text-sm text-gray-400">Admin Panel</span>
            </Link>

            <nav className="flex items-center gap-8 text-white">
              <Link href="/admin" className="hover:text-gray-300 font-semibold">
                Bosh sahifa
              </Link>
              <Link href="/admin/sellers" className="hover:text-gray-300">
                Sotuvchilar
              </Link>
              <Link href="/admin/products" className="hover:text-gray-300">
                Mahsulotlar
              </Link>
              <Link href="/admin/orders" className="hover:text-gray-300">
                Buyurtmalar
              </Link>
              <Link href="/admin/complaints" className="hover:text-gray-300">
                Shikoyatlar
              </Link>
              <Link href="/admin/pickup-points" className="hover:text-gray-300">
                Pickup Nuqtalari
              </Link>

              <button
                onClick={() => {
                  localStorage.removeItem("token");
                  localStorage.removeItem("user");
                  router.push("/");
                }}
                className="px-4 py-2 text-white hover:bg-slate-800 rounded"
              >
                Chiqish
              </button>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900">
            Admin Paneli
          </h1>
          <p className="text-gray-600 mt-1">Bittada platformasini boshqaring</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-4 mb-8">
          <div className="bg-white rounded-lg p-6 border border-gray-200">
            <div className="text-gray-600 text-sm font-medium">Jami foydalanuvchi</div>
            <div className="text-3xl font-bold text-slate-900 mt-2">0</div>
          </div>
          <div className="bg-white rounded-lg p-6 border border-gray-200">
            <div className="text-gray-600 text-sm font-medium">Sotuvchilar</div>
            <div className="text-3xl font-bold text-blue-600 mt-2">0</div>
          </div>
          <div className="bg-white rounded-lg p-6 border border-gray-200">
            <div className="text-gray-600 text-sm font-medium">Mahsulotlar</div>
            <div className="text-3xl font-bold text-green-600 mt-2">0</div>
          </div>
          <div className="bg-white rounded-lg p-6 border border-gray-200">
            <div className="text-gray-600 text-sm font-medium">Buyurtmalar</div>
            <div className="text-3xl font-bold text-yellow-600 mt-2">0</div>
          </div>
        </div>

        {/* Welcome Message */}
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-8 border border-blue-200">
          <h2 className="text-2xl font-bold text-slate-900 mb-2">
            Bittada platformasida xush kelibsiz
          </h2>
          <p className="text-gray-600">
            Yuqorida ko'rsatilgan menyu orqali platformaning barcha aspektlarini boshqarishingiz mumkin.
          </p>
        </div>
      </main>
    </div>
  );
}
