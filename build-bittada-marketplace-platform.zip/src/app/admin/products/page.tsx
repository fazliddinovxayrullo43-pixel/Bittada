"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function AdminProductsPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const userData = localStorage.getItem("user");

    if (!token || !userData) {
      router.push("/auth/login");
      return;
    }

    const parsedUser = JSON.parse(userData);
    if (parsedUser.role !== "admin") {
      router.push("/");
      return;
    }

    setUser(parsedUser);
  }, [router]);

  if (!user) {
    return <div className="text-center py-8">Yüklanmoqda...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-slate-900 text-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/admin" className="flex items-center gap-2">
              <div className="text-2xl font-bold">BITTADA</div>
              <span className="text-sm text-gray-400">Admin</span>
            </Link>

            <nav className="flex items-center gap-8 text-white">
              <Link href="/admin" className="hover:text-gray-300">
                Bosh sahifa
              </Link>
              <Link href="/admin/sellers" className="hover:text-gray-300">
                Sotuvchilar
              </Link>
              <Link href="/admin/products" className="hover:text-gray-300 font-semibold">
                Mahsulotlar
              </Link>
              <Link href="/admin/orders" className="hover:text-gray-300">
                Buyurtmalar
              </Link>

              <button
                onClick={() => {
                  localStorage.removeItem("token");
                  localStorage.removeItem("user");
                  router.push("/");
                }}
                className="px-4 py-2 text-white hover:bg-slate-800 rounded"
              >
                Chiqish
              </button>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-2xl font-bold text-slate-900 mb-8">Mahsulotlar Tasdiqlash</h1>

        {/* Tabs */}
        <div className="flex gap-4 mb-8 border-b border-gray-300">
          <button className="px-4 py-2 text-blue-600 font-semibold border-b-2 border-blue-600">
            Ko'rib chiqilayotgan (0)
          </button>
          <button className="px-4 py-2 text-gray-700 hover:text-blue-600">
            Tasdiqlangan (0)
          </button>
          <button className="px-4 py-2 text-gray-700 hover:text-blue-600">
            Rad etilgan (0)
          </button>
        </div>

        {/* Empty State */}
        <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
          <h2 className="text-xl font-bold text-slate-900 mb-2">
            Ko'rib chiqilayotgan mahsulot yo'q
          </h2>
          <p className="text-gray-600">
            Sotuvchilari mahsulot qo'shganida, ularni shu yerda ko'rasiz
          </p>
        </div>
      </main>
    </div>
  );
}
