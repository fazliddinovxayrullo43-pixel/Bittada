"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function AdminSellersPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const userData = localStorage.getItem("user");

    if (!token || !userData) {
      router.push("/auth/login");
      return;
    }

    const parsedUser = JSON.parse(userData);
    if (parsedUser.role !== "admin") {
      router.push("/");
      return;
    }

    setUser(parsedUser);
  }, [router]);

  if (!user) {
    return <div className="text-center py-8">Yüklanmoqda...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-slate-900 text-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/admin" className="flex items-center gap-2">
              <div className="text-2xl font-bold">BITTADA</div>
              <span className="text-sm text-gray-400">Admin</span>
            </Link>

            <nav className="flex items-center gap-8 text-white">
              <Link href="/admin" className="hover:text-gray-300">
                Bosh sahifa
              </Link>
              <Link href="/admin/sellers" className="hover:text-gray-300 font-semibold">
                Sotuvchilar
              </Link>
              <Link href="/admin/products" className="hover:text-gray-300">
                Mahsulotlar
              </Link>
              <Link href="/admin/orders" className="hover:text-gray-300">
                Buyurtmalar
              </Link>

              <button
                onClick={() => {
                  localStorage.removeItem("token");
                  localStorage.removeItem("user");
                  router.push("/");
                }}
                className="px-4 py-2 text-white hover:bg-slate-800 rounded"
              >
                Chiqish
              </button>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-2xl font-bold text-slate-900 mb-8">Sotuvchilar Boshqaruvi</h1>

        {/* Empty State */}
        <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
          <h2 className="text-xl font-bold text-slate-900 mb-2">
            Sotuvchilar yo'q
          </h2>
          <p className="text-gray-600">
            Birinchi sotuvchi ro'yxatdan o'tganida, uni shu yerda ko'rasiz
          </p>
        </div>
      </main>
    </div>
  );
}
