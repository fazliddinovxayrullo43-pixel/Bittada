"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function ProfilePage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const userData = localStorage.getItem("user");
    
    if (!token || !userData) {
      router.push("/auth/login");
      return;
    }

    const parsedUser = JSON.parse(userData);
    if (parsedUser.role !== "customer") {
      router.push("/");
      return;
    }

    setUser(parsedUser);
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    router.push("/");
  };

  if (!user) {
    return <div className="text-center py-8">Yüklanmoqda...</div>;
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <div className="text-2xl font-bold text-blue-600">BITTADA</div>
            </Link>

            <nav className="flex items-center gap-6">
              <Link href="/" className="text-gray-700 hover:text-blue-600">
                Bosh sahifa
              </Link>
              <Link href="/orders" className="text-gray-700 hover:text-blue-600">
                Buyurtmalar
              </Link>
              <Link href="/cart" className="text-gray-700 hover:text-blue-600">
                Savatcha
              </Link>
              <Link href="/profile" className="text-blue-600 font-semibold">
                Profil
              </Link>

              <button
                onClick={handleLogout}
                className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600"
              >
                Chiqish
              </button>

              <Link
                href="/seller"
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                Sotuvchi bo'lish
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-2xl font-bold text-slate-900 mb-8">Mening Profilim</h1>

        <div className="bg-white rounded-lg border border-gray-200 p-8">
          <div className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                To'liq ismi
              </label>
              <p className="text-slate-900 font-semibold">{user.full_name}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Email
              </label>
              <p className="text-slate-900 font-semibold">{user.email}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Telefon
              </label>
              <p className="text-slate-900 font-semibold">{user.phone}</p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Rol
              </label>
              <p className="text-slate-900 font-semibold">
                {user.role === "customer" ? "Xaridor" : "Sotuvchi"}
              </p>
            </div>

            <div className="pt-6 border-t border-gray-200">
              <button
                onClick={handleLogout}
                className="w-full px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 font-semibold"
              >
                Profildan Chiqish
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
