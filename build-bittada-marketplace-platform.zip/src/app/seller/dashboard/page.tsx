"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function SellerDashboard() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [stats, setStats] = useState({
    totalProducts: 0,
    activeProducts: 0,
    totalOrders: 0,
    pendingOrders: 0,
    revenue: 0,
  });

  useEffect(() => {
    const token = localStorage.getItem("token");
    const userData = localStorage.getItem("user");

    if (!token || !userData) {
      router.push("/auth/login");
      return;
    }

    const parsedUser = JSON.parse(userData);
    if (parsedUser.role !== "seller") {
      router.push("/");
      return;
    }

    setUser(parsedUser);

    // In a real app, fetch actual stats from API
    setStats({
      totalProducts: 0,
      activeProducts: 0,
      totalOrders: 0,
      pendingOrders: 0,
      revenue: 0,
    });
  }, [router]);

  if (!user) {
    return <div className="text-center py-8">Yüklanmoqda...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/seller" className="flex items-center gap-2">
              <div className="text-2xl font-bold text-blue-600">BITTADA</div>
              <span className="text-sm text-gray-600">Sotuvchi Kabinetl</span>
            </Link>

            <nav className="flex items-center gap-8">
              <Link href="/seller/dashboard" className="text-blue-600 font-semibold">
                Bosh sahifa
              </Link>
              <Link href="/seller/products" className="text-gray-700 hover:text-blue-600">
                Mahsulotlar
              </Link>
              <Link href="/seller/orders" className="text-gray-700 hover:text-blue-600">
                Buyurtmalar
              </Link>
              <Link href="/seller/inventory" className="text-gray-700 hover:text-blue-600">
                Inventar
              </Link>

              <button
                onClick={() => {
                  localStorage.removeItem("token");
                  localStorage.removeItem("user");
                  router.push("/");
                }}
                className="px-4 py-2 text-gray-700 hover:text-gray-900"
              >
                Chiqish
              </button>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900">
            Assalomu alaikum, {user.full_name}
          </h1>
          <p className="text-gray-600 mt-1">Sotuvchi kabinetiga xush kelibsiz</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-5 gap-4 mb-8">
          <div className="bg-white rounded-lg p-6 border border-gray-200">
            <div className="text-gray-600 text-sm font-medium">Jami mahsulot</div>
            <div className="text-3xl font-bold text-slate-900 mt-2">
              {stats.totalProducts}
            </div>
          </div>
          <div className="bg-white rounded-lg p-6 border border-gray-200">
            <div className="text-gray-600 text-sm font-medium">Faol mahsulot</div>
            <div className="text-3xl font-bold text-green-600 mt-2">
              {stats.activeProducts}
            </div>
          </div>
          <div className="bg-white rounded-lg p-6 border border-gray-200">
            <div className="text-gray-600 text-sm font-medium">Jami buyurtma</div>
            <div className="text-3xl font-bold text-slate-900 mt-2">
              {stats.totalOrders}
            </div>
          </div>
          <div className="bg-white rounded-lg p-6 border border-gray-200">
            <div className="text-gray-600 text-sm font-medium">Kutilayotgan</div>
            <div className="text-3xl font-bold text-yellow-600 mt-2">
              {stats.pendingOrders}
            </div>
          </div>
          <div className="bg-white rounded-lg p-6 border border-gray-200">
            <div className="text-gray-600 text-sm font-medium">Tushum</div>
            <div className="text-3xl font-bold text-blue-600 mt-2">
              {stats.revenue.toLocaleString()} so'm
            </div>
          </div>
        </div>

        {/* Empty State */}
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg p-12 text-center">
          <h2 className="text-2xl font-bold text-slate-900 mb-4">
            Hali mahsulot qo'shilmagan
          </h2>
          <p className="text-gray-700 mb-8">
            Sotishni boshlash uchun birinchi mahsulotingizni qo'shing
          </p>

          <Link
            href="/seller/products/create"
            className="inline-block px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold"
          >
            Mahsulot Qo'shish
          </Link>
        </div>

        {/* Recent Orders Section */}
        <div className="mt-12">
          <h2 className="text-2xl font-bold text-slate-900 mb-6">So'nggi buyurtmalar</h2>
          <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
            <p className="text-gray-600">Hali buyurtma yo'q</p>
          </div>
        </div>
      </main>
    </div>
  );
}
