"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function ProductsPage() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const userData = localStorage.getItem("user");

    if (!token || !userData) {
      router.push("/auth/login");
      return;
    }

    const parsedUser = JSON.parse(userData);
    if (parsedUser.role !== "seller") {
      router.push("/");
      return;
    }

    setUser(parsedUser);
  }, [router]);

  if (!user) {
    return <div className="text-center py-8">Yüklanmoqda...</div>;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/seller" className="flex items-center gap-2">
              <div className="text-2xl font-bold text-blue-600">BITTADA</div>
            </Link>

            <nav className="flex items-center gap-8">
              <Link href="/seller/dashboard" className="text-gray-700 hover:text-blue-600">
                Bosh sahifa
              </Link>
              <Link href="/seller/products" className="text-blue-600 font-semibold">
                Mahsulotlar
              </Link>
              <Link href="/seller/orders" className="text-gray-700 hover:text-blue-600">
                Buyurtmalar
              </Link>

              <button
                onClick={() => {
                  localStorage.removeItem("token");
                  localStorage.removeItem("user");
                  router.push("/");
                }}
                className="px-4 py-2 text-gray-700 hover:text-gray-900"
              >
                Chiqish
              </button>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-2xl font-bold text-slate-900">Mahsulotlar</h1>
          <Link
            href="/seller/products/create"
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold"
          >
            Yangi Mahsulot
          </Link>
        </div>

        {/* Empty State */}
        <div className="bg-white rounded-lg border border-gray-200 p-12 text-center">
          <h2 className="text-xl font-bold text-slate-900 mb-2">
            Hali mahsulot qo'shilmagan
          </h2>
          <p className="text-gray-600 mb-6">
            Sotishni boshlash uchun birinchi mahsulotingizni qo'shing
          </p>
          <Link
            href="/seller/products/create"
            className="inline-block px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold"
          >
            Mahsulot Qo'shish
          </Link>
        </div>
      </main>
    </div>
  );
}
