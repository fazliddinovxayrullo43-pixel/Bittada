"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function SellerPage() {
  const router = useRouter();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<any>(null);
  const [hasSellerProfile, setHasSellerProfile] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const userData = localStorage.getItem("user");
    
    if (!token || !userData) {
      router.push("/auth/login");
      return;
    }

    const parsedUser = JSON.parse(userData);
    setUser(parsedUser);
    setIsLoggedIn(true);

    // Check if user has seller profile
    // This is simplified - in real app would fetch from API
    if (parsedUser.role === "seller") {
      setHasSellerProfile(true);
    }
  }, [router]);

  if (!isLoggedIn) {
    return <div className="text-center py-8">Yüklanmoqda...</div>;
  }

  if (user?.role === "seller" && hasSellerProfile) {
    router.push("/seller/dashboard");
    return null;
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <div className="text-2xl font-bold text-blue-600">BITTADA</div>
              <span className="text-sm text-gray-600">Sotuvchi</span>
            </Link>
            <button
              onClick={() => {
                localStorage.removeItem("token");
                localStorage.removeItem("user");
                router.push("/");
              }}
              className="px-4 py-2 text-gray-700 hover:text-gray-900"
            >
              Chiqish
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <h1 className="text-5xl font-bold text-slate-900 mb-4">
            Bittada'da Sotuvchi Platformasi
          </h1>
          <p className="text-xl text-gray-600 mb-12">
            Mahsulotlaringizni Bittada'da soting va butun O'zbekistan bo'ylab o'z biznesini rivojlantiring
          </p>

          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-lg p-12 mb-12">
            <h2 className="text-2xl font-bold text-slate-900 mb-8">
              Sotuvchi sifatida boshlang
            </h2>

            <div className="grid grid-cols-3 gap-6 mb-12">
              <div className="bg-white rounded-lg p-6">
                <div className="text-4xl font-bold text-green-600 mb-2">1</div>
                <h3 className="font-bold text-lg mb-2">Ro'yxatdan o'tish</h3>
                <p className="text-gray-600">
                  Sotuvchi profilini yaratib, biznes ma'lumotlarini kiriting
                </p>
              </div>

              <div className="bg-white rounded-lg p-6">
                <div className="text-4xl font-bold text-green-600 mb-2">2</div>
                <h3 className="font-bold text-lg mb-2">Tasdiqlantirish</h3>
                <p className="text-gray-600">
                  Admin jamoasi sizning ma'lumotlaringizni tekshiradi
                </p>
              </div>

              <div className="bg-white rounded-lg p-6">
                <div className="text-4xl font-bold text-green-600 mb-2">3</div>
                <h3 className="font-bold text-lg mb-2">Sotishni boshlang</h3>
                <p className="text-gray-600">
                  Mahsulotlarni qo'shib, buyurtmalarni qabul qiling
                </p>
              </div>
            </div>

            <div className="flex justify-center gap-4">
              <Link
                href="/seller/register"
                className="px-8 py-3 bg-green-600 text-white rounded-lg hover:bg-green-700 text-lg font-semibold"
              >
                Ro'yxatdan o'tish
              </Link>
              <Link
                href="/seller/login"
                className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-lg font-semibold"
              >
                Kabinanga kirish
              </Link>
            </div>
          </div>

          {/* Benefits */}
          <div className="grid grid-cols-2 gap-8">
            <div className="text-left">
              <h3 className="text-xl font-bold mb-4">Nima uchun Bittada?</h3>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold">✓</span>
                  <span>Butun O'zbekistan bo'ylab buyurtmalar</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold">✓</span>
                  <span>To'liq pickup tarmog'i</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold">✓</span>
                  <span>Xavfsiz to'lovlar</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold">✓</span>
                  <span>Professional kabinet</span>
                </li>
              </ul>
            </div>

            <div className="text-left">
              <h3 className="text-xl font-bold mb-4">Xususiyatlar</h3>
              <ul className="space-y-3 text-gray-600">
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold">✓</span>
                  <span>Osonlik bilan mahsulot qo'shish</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold">✓</span>
                  <span>Buyurtmalarni boshqarish</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold">✓</span>
                  <span>Inventarizni kuzatish</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 font-bold">✓</span>
                  <span>Moliyaviy hisobotlar</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 text-white mt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-400">
            <p>&copy; 2024 BITTADA Sotuvchi Platformasi. Barcha huquqlar himoya qilingan.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
