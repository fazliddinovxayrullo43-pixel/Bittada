"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";

export default function CartPage() {
  const router = useRouter();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    const userData = localStorage.getItem("user");
    
    if (!token || !userData) {
      setIsLoggedIn(false);
      return;
    }

    const parsedUser = JSON.parse(userData);
    if (parsedUser.role !== "customer") {
      router.push("/");
      return;
    }

    setUser(parsedUser);
    setIsLoggedIn(true);
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    router.push("/auth/login");
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center gap-2">
              <div className="text-2xl font-bold text-blue-600">BITTADA</div>
            </Link>

            <nav className="flex items-center gap-6">
              <Link href="/" className="text-gray-700 hover:text-blue-600">
                Bosh sahifa
              </Link>
              <Link href="/orders" className="text-gray-700 hover:text-blue-600">
                Buyurtmalar
              </Link>
              <Link href="/cart" className="text-blue-600 font-semibold">
                Savatcha
              </Link>

              {isLoggedIn ? (
                <div className="flex items-center gap-4">
                  <Link href="/profile" className="text-gray-700 hover:text-blue-600">
                    Profil
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600"
                  >
                    Chiqish
                  </button>
                </div>
              ) : (
                <Link
                  href="/auth/login"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Kirish
                </Link>
              )}

              <Link
                href="/seller"
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
              >
                Sotuvchi bo'lish
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {!isLoggedIn ? (
          <div className="text-center py-12">
            <h1 className="text-2xl font-bold text-slate-900 mb-4">
              Savatcha bo'sh
            </h1>
            <p className="text-gray-600 mb-8">
              Mahsulot qo'shish uchun avval akkauntga kirish kerak
            </p>
            <Link
              href="/auth/login"
              className="inline-block px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold"
            >
              Kirish
            </Link>
          </div>
        ) : (
          <div>
            <h1 className="text-2xl font-bold text-slate-900 mb-8">Savatcha</h1>

            {/* Empty State */}
            <div className="bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg p-12 text-center">
              <h2 className="text-xl font-bold text-slate-900 mb-4">
                Savatcha bo'sh
              </h2>
              <p className="text-gray-600 mb-8">
                Mahsulot qo'shish uchun bosh sahifaga o'ting
              </p>
              <Link
                href="/"
                className="inline-block px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 font-semibold"
              >
                Mahsulot Qidirish
              </Link>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
