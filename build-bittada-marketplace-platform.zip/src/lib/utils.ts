import crypto from "crypto";

/**
 * Generate a unique 4-digit pickup code
 * Uses cryptographic randomness to ensure unpredictability
 */
export function generatePickupCode(): string {
  // Generate 2 random bytes and convert to integer in range 0-9999
  const randomBytes = crypto.randomBytes(2);
  const randomNum = randomBytes.readUInt16BE(0) % 10000;
  return String(randomNum).padStart(4, "0");
}

/**
 * Generate a unique order number with prefix BT
 */
export function generateOrderNumber(): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = crypto.randomBytes(2).toString("hex").toUpperCase();
  return `BT${timestamp}${random}`;
}

/**
 * Generate a unique refund number with prefix RF
 */
export function generateRefundNumber(): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = crypto.randomBytes(2).toString("hex").toUpperCase();
  return `RF${timestamp}${random}`;
}

/**
 * Generate a unique complaint number with prefix CM
 */
export function generateComplaintNumber(): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = crypto.randomBytes(2).toString("hex").toUpperCase();
  return `CM${timestamp}${random}`;
}

/**
 * Validate Uzbek phone number format
 */
export function isValidPhoneNumber(phone: string): boolean {
  // Uzbek phone numbers: +998XXXXXXXXX or 998XXXXXXXXX or 0XXXXXXXXX
  const phoneRegex = /^(\+?998|0)\d{9}$/;
  return phoneRegex.test(phone.replace(/\s|-/g, ""));
}

/**
 * Format price with currency
 */
export function formatPrice(price: number | string, currency: string = "UZS"): string {
  const num = typeof price === "string" ? parseFloat(price) : price;
  if (currency === "UZS") {
    return num.toLocaleString("uz-UZ", { minimumFractionDigits: 0, maximumFractionDigits: 0 }) + " so'm";
  }
  return num.toLocaleString("uz-UZ", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " " + currency;
}

/**
 * Validate email
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Slugify text
 */
export function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

/**
 * Get time ago string
 */
export function getTimeAgo(date: Date): string {
  const now = new Date();
  const seconds = Math.floor((now.getTime() - date.getTime()) / 1000);

  const intervals: { [key: string]: number } = {
    year: 31536000,
    month: 2592000,
    week: 604800,
    day: 86400,
    hour: 3600,
    minute: 60,
  };

  for (const [key, value] of Object.entries(intervals)) {
    const interval = Math.floor(seconds / value);
    if (interval >= 1) {
      return interval === 1 ? `1 ${key} ago` : `${interval} ${key}s ago`;
    }
  }

  return "just now";
}
