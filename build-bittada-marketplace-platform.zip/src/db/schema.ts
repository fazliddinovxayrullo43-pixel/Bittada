import {
  pgTable,
  text,
  varchar,
  integer,
  decimal,
  timestamp,
  uuid,
  boolean,
  jsonb,
  smallint,
  index,
  foreignKey,
  uniqueIndex,
  primaryKey,
} from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";

// ============================================================================
// USERS & AUTHENTICATION
// ============================================================================

export const users = pgTable(
  "users",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    email: varchar("email", { length: 255 }).notNull().unique(),
    password_hash: text("password_hash").notNull(),
    full_name: varchar("full_name", { length: 255 }).notNull(),
    phone: varchar("phone", { length: 20 }).notNull().unique(),
    role: varchar("role", { length: 20 }).notNull().default("customer"), // customer, seller, admin
    avatar_url: text("avatar_url"),
    is_active: boolean("is_active").notNull().default(true),
    created_at: timestamp("created_at").notNull().defaultNow(),
    updated_at: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => ({
    emailIdx: index("users_email_idx").on(table.email),
    phoneIdx: index("users_phone_idx").on(table.phone),
    roleIdx: index("users_role_idx").on(table.role),
  })
);

// ============================================================================
// SELLER PROFILES
// ============================================================================

export const sellerProfiles = pgTable(
  "seller_profiles",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    user_id: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    business_name: varchar("business_name", { length: 255 }).notNull(),
    seller_type: varchar("seller_type", { length: 50 }).notNull(), // individual, business, company
    address: text("address").notNull(),
    city: varchar("city", { length: 100 }).notNull(),
    phone: varchar("phone", { length: 20 }).notNull(),
    description: text("description"),
    logo_url: text("logo_url"),
    verification_status: varchar("verification_status", {
      length: 30,
    }).notNull().default("pending"), // pending, approved, rejected, suspended
    verification_documents: jsonb("verification_documents"),
    verified_at: timestamp("verified_at"),
    bank_account: varchar("bank_account", { length: 100 }),
    commission_rate: smallint("commission_rate").default(10), // percentage
    total_products: integer("total_products").default(0),
    total_orders: integer("total_orders").default(0),
    rating: decimal("rating", { precision: 3, scale: 2 }).default("0"),
    is_active: boolean("is_active").notNull().default(true),
    created_at: timestamp("created_at").notNull().defaultNow(),
    updated_at: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => ({
    userIdIdx: index("seller_profiles_user_id_idx").on(table.user_id),
    statusIdx: index("seller_profiles_verification_status_idx").on(
      table.verification_status
    ),
  })
);

// ============================================================================
// CATEGORIES
// ============================================================================

export const categories = pgTable("categories", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 255 }).notNull().unique(),
  description: text("description"),
  icon_url: text("icon_url"),
  slug: varchar("slug", { length: 255 }).notNull().unique(),
  parent_id: uuid("parent_id"),
  is_active: boolean("is_active").notNull().default(true),
  created_at: timestamp("created_at").notNull().defaultNow(),
});

// ============================================================================
// PRODUCTS
// ============================================================================

export const products = pgTable(
  "products",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    seller_id: uuid("seller_id")
      .notNull()
      .references(() => sellerProfiles.id, { onDelete: "cascade" }),
    category_id: uuid("category_id").references(() => categories.id),
    name: varchar("name", { length: 255 }).notNull(),
    description: text("description"),
    price: decimal("price", { precision: 10, scale: 2 }).notNull(),
    currency: varchar("currency", { length: 3 }).notNull().default("UZS"),
    sku: varchar("sku", { length: 100 }),
    stock_quantity: integer("stock_quantity").notNull().default(0),
    weight: decimal("weight", { precision: 8, scale: 2 }), // grams
    dimensions: jsonb("dimensions"), // { length, width, height } in cm
    status: varchar("status", { length: 30 }).notNull().default("draft"), // draft, pending_review, approved, rejected, inactive
    rating: decimal("rating", { precision: 3, scale: 2 }).default("0"),
    review_count: integer("review_count").default(0),
    view_count: integer("view_count").default(0),
    created_at: timestamp("created_at").notNull().defaultNow(),
    updated_at: timestamp("updated_at").notNull().defaultNow(),
    rejected_reason: text("rejected_reason"),
  },
  (table) => ({
    sellerIdIdx: index("products_seller_id_idx").on(table.seller_id),
    categoryIdIdx: index("products_category_id_idx").on(table.category_id),
    statusIdx: index("products_status_idx").on(table.status),
    skuIdx: uniqueIndex("products_sku_idx").on(table.sku),
  })
);

// ============================================================================
// PRODUCT IMAGES
// ============================================================================

export const productImages = pgTable(
  "product_images",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    product_id: uuid("product_id")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    image_url: text("image_url").notNull(),
    alt_text: varchar("alt_text", { length: 255 }),
    sort_order: integer("sort_order").default(0),
    created_at: timestamp("created_at").notNull().defaultNow(),
  },
  (table) => ({
    productIdIdx: index("product_images_product_id_idx").on(table.product_id),
  })
);

// ============================================================================
// CART & CART ITEMS
// ============================================================================

export const cart = pgTable(
  "cart",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    customer_id: uuid("customer_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    expires_at: timestamp("expires_at").notNull(),
    created_at: timestamp("created_at").notNull().defaultNow(),
    updated_at: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => ({
    customerIdIdx: uniqueIndex("cart_customer_id_idx").on(table.customer_id),
  })
);

export const cartItems = pgTable(
  "cart_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    cart_id: uuid("cart_id")
      .notNull()
      .references(() => cart.id, { onDelete: "cascade" }),
    product_id: uuid("product_id")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    quantity: integer("quantity").notNull().default(1),
    price_at_addition: decimal("price_at_addition", { precision: 10, scale: 2 }).notNull(),
    created_at: timestamp("created_at").notNull().defaultNow(),
    updated_at: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => ({
    cartIdIdx: index("cart_items_cart_id_idx").on(table.cart_id),
    productIdIdx: index("cart_items_product_id_idx").on(table.product_id),
  })
);

// ============================================================================
// PICKUP POINTS
// ============================================================================

export const pickupPoints = pgTable(
  "pickup_points",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    name: varchar("name", { length: 255 }).notNull(),
    city: varchar("city", { length: 100 }).notNull(),
    district: varchar("district", { length: 100 }),
    address: text("address").notNull(),
    phone: varchar("phone", { length: 20 }),
    working_hours: jsonb("working_hours"), // { monday: "08:00-20:00", ... }
    latitude: decimal("latitude", { precision: 9, scale: 6 }),
    longitude: decimal("longitude", { precision: 9, scale: 6 }),
    status: varchar("status", { length: 20 }).notNull().default("active"), // active, inactive
    capacity: integer("capacity"), // max orders at a time
    created_at: timestamp("created_at").notNull().defaultNow(),
    updated_at: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => ({
    cityIdx: index("pickup_points_city_idx").on(table.city),
    statusIdx: index("pickup_points_status_idx").on(table.status),
  })
);

// ============================================================================
// PICKUP CODES (UNIQUE 4-DIGIT CODES FOR ORDERS)
// ============================================================================

export const pickupCodes = pgTable(
  "pickup_codes",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    code: varchar("code", { length: 4 }).notNull().unique(),
    order_id: uuid("order_id").notNull(), // Will reference orders table
    generated_at: timestamp("generated_at").notNull().defaultNow(),
    expires_at: timestamp("expires_at"),
    is_used: boolean("is_used").default(false),
    used_at: timestamp("used_at"),
  },
  (table) => ({
    codeIdx: uniqueIndex("pickup_codes_code_idx").on(table.code),
    orderIdIdx: index("pickup_codes_order_id_idx").on(table.order_id),
  })
);

// ============================================================================
// ORDERS
// ============================================================================

export const orders = pgTable(
  "orders",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    order_number: varchar("order_number", { length: 50 }).notNull().unique(),
    customer_id: uuid("customer_id")
      .notNull()
      .references(() => users.id, { onDelete: "restrict" }),
    pickup_point_id: uuid("pickup_point_id")
      .notNull()
      .references(() => pickupPoints.id, { onDelete: "restrict" }),
    pickup_code: varchar("pickup_code", { length: 4 }).notNull().unique(),
    subtotal: decimal("subtotal", { precision: 12, scale: 2 }).notNull(),
    delivery_fee: decimal("delivery_fee", { precision: 10, scale: 2 }).default("0"),
    discount: decimal("discount", { precision: 10, scale: 2 }).default("0"),
    total: decimal("total", { precision: 12, scale: 2 }).notNull(),
    payment_method: varchar("payment_method", { length: 30 }).notNull(), // cash_on_delivery, card, etc
    payment_status: varchar("payment_status", { length: 20 }).notNull().default("pending"), // pending, completed, failed
    currency: varchar("currency", { length: 3 }).notNull().default("UZS"),
    customer_phone: varchar("customer_phone", { length: 20 }).notNull(),
    customer_notes: text("customer_notes"),
    status: varchar("status", { length: 30 }).notNull().default("new"), // new, confirmed, preparing, ready_for_shipment, shipped, at_warehouse, at_pickup_point, completed, cancelled, return_requested
    is_active: boolean("is_active").notNull().default(true),
    created_at: timestamp("created_at").notNull().defaultNow(),
    updated_at: timestamp("updated_at").notNull().defaultNow(),
    completed_at: timestamp("completed_at"),
  },
  (table) => ({
    customerIdIdx: index("orders_customer_id_idx").on(table.customer_id),
    pickupPointIdIdx: index("orders_pickup_point_id_idx").on(table.pickup_point_id),
    orderNumberIdx: uniqueIndex("orders_order_number_idx").on(table.order_number),
    pickupCodeIdx: uniqueIndex("orders_pickup_code_idx").on(table.pickup_code),
    statusIdx: index("orders_status_idx").on(table.status),
  })
);

// ============================================================================
// ORDER ITEMS
// ============================================================================

export const orderItems = pgTable(
  "order_items",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    order_id: uuid("order_id")
      .notNull()
      .references(() => orders.id, { onDelete: "cascade" }),
    product_id: uuid("product_id")
      .notNull()
      .references(() => products.id, { onDelete: "restrict" }),
    seller_id: uuid("seller_id")
      .notNull()
      .references(() => sellerProfiles.id, { onDelete: "restrict" }),
    product_name: varchar("product_name", { length: 255 }).notNull(),
    quantity: integer("quantity").notNull(),
    price_per_unit: decimal("price_per_unit", { precision: 10, scale: 2 }).notNull(),
    subtotal: decimal("subtotal", { precision: 12, scale: 2 }).notNull(),
    status: varchar("status", { length: 30 }).notNull().default("new"), // new, confirmed, preparing, ready, shipped, delivered, returned
    created_at: timestamp("created_at").notNull().defaultNow(),
    updated_at: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => ({
    orderIdIdx: index("order_items_order_id_idx").on(table.order_id),
    productIdIdx: index("order_items_product_id_idx").on(table.product_id),
    sellerIdIdx: index("order_items_seller_id_idx").on(table.seller_id),
  })
);

// ============================================================================
// ORDER STATUS HISTORY
// ============================================================================

export const orderStatusHistory = pgTable(
  "order_status_history",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    order_id: uuid("order_id")
      .notNull()
      .references(() => orders.id, { onDelete: "cascade" }),
    from_status: varchar("from_status", { length: 30 }),
    to_status: varchar("to_status", { length: 30 }).notNull(),
    changed_by_user_id: uuid("changed_by_user_id").references(() => users.id),
    notes: text("notes"),
    created_at: timestamp("created_at").notNull().defaultNow(),
  },
  (table) => ({
    orderIdIdx: index("order_status_history_order_id_idx").on(table.order_id),
  })
);

// ============================================================================
// REVIEWS
// ============================================================================

export const reviews = pgTable(
  "reviews",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    product_id: uuid("product_id")
      .notNull()
      .references(() => products.id, { onDelete: "cascade" }),
    order_item_id: uuid("order_item_id")
      .notNull()
      .references(() => orderItems.id, { onDelete: "cascade" }),
    customer_id: uuid("customer_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    rating: smallint("rating").notNull(), // 1-5
    title: varchar("title", { length: 255 }),
    text: text("text"),
    is_verified_purchase: boolean("is_verified_purchase").notNull().default(true),
    helpful_count: integer("helpful_count").default(0),
    created_at: timestamp("created_at").notNull().defaultNow(),
    updated_at: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => ({
    productIdIdx: index("reviews_product_id_idx").on(table.product_id),
    customerIdIdx: index("reviews_customer_id_idx").on(table.customer_id),
  })
);

// ============================================================================
// COMPLAINTS
// ============================================================================

export const complaints = pgTable(
  "complaints",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    complaint_number: varchar("complaint_number", { length: 50 }).notNull().unique(),
    order_id: uuid("order_id")
      .notNull()
      .references(() => orders.id, { onDelete: "restrict" }),
    product_id: uuid("product_id").references(() => products.id),
    customer_id: uuid("customer_id")
      .notNull()
      .references(() => users.id, { onDelete: "restrict" }),
    seller_id: uuid("seller_id")
      .notNull()
      .references(() => sellerProfiles.id, { onDelete: "restrict" }),
    reason: varchar("reason", { length: 100 }).notNull(), // mismatch, damaged, wrong_product, missing_item, quality, other
    description: text("description").notNull(),
    images_json: jsonb("images_json"), // array of image urls
    status: varchar("status", { length: 30 }).notNull().default("open"), // open, in_review, resolved, rejected
    resolution_type: varchar("resolution_type", { length: 30 }), // none, partial_refund, full_refund, replacement
    resolved_at: timestamp("resolved_at"),
    admin_notes: text("admin_notes"),
    created_at: timestamp("created_at").notNull().defaultNow(),
    updated_at: timestamp("updated_at").notNull().defaultNow(),
  },
  (table) => ({
    orderIdIdx: index("complaints_order_id_idx").on(table.order_id),
    customerIdIdx: index("complaints_customer_id_idx").on(table.customer_id),
    sellerIdIdx: index("complaints_seller_id_idx").on(table.seller_id),
    statusIdx: index("complaints_status_idx").on(table.status),
  })
);

// ============================================================================
// REFUNDS
// ============================================================================

export const refunds = pgTable(
  "refunds",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    refund_number: varchar("refund_number", { length: 50 }).notNull().unique(),
    order_id: uuid("order_id")
      .notNull()
      .references(() => orders.id, { onDelete: "restrict" }),
    complaint_id: uuid("complaint_id").references(() => complaints.id),
    customer_id: uuid("customer_id")
      .notNull()
      .references(() => users.id, { onDelete: "restrict" }),
    amount: decimal("amount", { precision: 12, scale: 2 }).notNull(),
    reason: varchar("reason", { length: 100 }).notNull(),
    status: varchar("status", { length: 20 }).notNull().default("requested"), // requested, reviewing, approved, rejected, completed
    notes: text("notes"),
    created_at: timestamp("created_at").notNull().defaultNow(),
    processed_at: timestamp("processed_at"),
    processed_by_id: uuid("processed_by_id").references(() => users.id),
  },
  (table) => ({
    orderIdIdx: index("refunds_order_id_idx").on(table.order_id),
    customerIdIdx: index("refunds_customer_id_idx").on(table.customer_id),
    statusIdx: index("refunds_status_idx").on(table.status),
  })
);

// ============================================================================
// NOTIFICATIONS
// ============================================================================

export const notifications = pgTable(
  "notifications",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    user_id: uuid("user_id")
      .notNull()
      .references(() => users.id, { onDelete: "cascade" }),
    type: varchar("type", { length: 50 }).notNull(), // order_created, order_confirmed, order_shipped, complaint_update, etc
    title: varchar("title", { length: 255 }).notNull(),
    message: text("message"),
    related_order_id: uuid("related_order_id").references(() => orders.id),
    related_complaint_id: uuid("related_complaint_id").references(() => complaints.id),
    is_read: boolean("is_read").notNull().default(false),
    read_at: timestamp("read_at"),
    created_at: timestamp("created_at").notNull().defaultNow(),
  },
  (table) => ({
    userIdIdx: index("notifications_user_id_idx").on(table.user_id),
    typeIdx: index("notifications_type_idx").on(table.type),
    isReadIdx: index("notifications_is_read_idx").on(table.is_read),
  })
);

// ============================================================================
// ADMIN ACTIONS LOG
// ============================================================================

export const adminActions = pgTable(
  "admin_actions",
  {
    id: uuid("id").defaultRandom().primaryKey(),
    admin_id: uuid("admin_id")
      .notNull()
      .references(() => users.id, { onDelete: "restrict" }),
    action_type: varchar("action_type", { length: 100 }).notNull(), // approve_seller, reject_product, create_pickup_point, etc
    target_type: varchar("target_type", { length: 50 }).notNull(), // seller, product, user, pickup_point
    target_id: varchar("target_id", { length: 100 }),
    details: jsonb("details"),
    notes: text("notes"),
    created_at: timestamp("created_at").notNull().defaultNow(),
  },
  (table) => ({
    adminIdIdx: index("admin_actions_admin_id_idx").on(table.admin_id),
    actionTypeIdx: index("admin_actions_action_type_idx").on(table.action_type),
  })
);

// ============================================================================
// RELATIONSHIPS (OPTIONAL - for type safety in Drizzle queries)
// ============================================================================

export const usersRelations = relations(users, ({ one, many }) => ({
  sellerProfile: one(sellerProfiles, {
    fields: [users.id],
    references: [sellerProfiles.user_id],
  }),
  orders: many(orders),
  cart: one(cart),
  notifications: many(notifications),
  reviews: many(reviews),
  complaints: many(complaints),
}));

export const sellerProfilesRelations = relations(
  sellerProfiles,
  ({ one, many }) => ({
    user: one(users, {
      fields: [sellerProfiles.user_id],
      references: [users.id],
    }),
    products: many(products),
    orderItems: many(orderItems),
  })
);

export const productsRelations = relations(products, ({ one, many }) => ({
  seller: one(sellerProfiles, {
    fields: [products.seller_id],
    references: [sellerProfiles.id],
  }),
  category: one(categories, {
    fields: [products.category_id],
    references: [categories.id],
  }),
  images: many(productImages),
  reviews: many(reviews),
  orderItems: many(orderItems),
}));

export const ordersRelations = relations(orders, ({ one, many }) => ({
  customer: one(users, {
    fields: [orders.customer_id],
    references: [users.id],
  }),
  pickupPoint: one(pickupPoints, {
    fields: [orders.pickup_point_id],
    references: [pickupPoints.id],
  }),
  items: many(orderItems),
  statusHistory: many(orderStatusHistory),
  complaints: many(complaints),
  refunds: many(refunds),
}));

export const orderItemsRelations = relations(orderItems, ({ one, many }) => ({
  order: one(orders, {
    fields: [orderItems.order_id],
    references: [orders.id],
  }),
  product: one(products, {
    fields: [orderItems.product_id],
    references: [products.id],
  }),
  seller: one(sellerProfiles, {
    fields: [orderItems.seller_id],
    references: [sellerProfiles.id],
  }),
  reviews: many(reviews),
}));

export const complaintsRelations = relations(complaints, ({ one }) => ({
  order: one(orders, {
    fields: [complaints.order_id],
    references: [orders.id],
  }),
  customer: one(users, {
    fields: [complaints.customer_id],
    references: [users.id],
  }),
  seller: one(sellerProfiles, {
    fields: [complaints.seller_id],
    references: [sellerProfiles.id],
  }),
}));
