# BITTADA - Complete Setup & Deployment Guide

## 📋 Table of Contents

1. [Local Development Setup](#local-development-setup)
2. [Database Configuration](#database-configuration)
3. [Environment Variables](#environment-variables)
4. [Running the Application](#running-the-application)
5. [Testing the Complete Flow](#testing-the-complete-flow)
6. [Deployment Guide](#deployment-guide)
7. [API Documentation](#api-documentation)
8. [Troubleshooting](#troubleshooting)

---

## 🚀 Local Development Setup

### Prerequisites

- **Node.js**: v18.0.0 or higher
- **npm**: v9.0.0 or higher (or yarn/pnpm)
- **PostgreSQL**: v15 or higher
- **Git**: For version control

### Step 1: Clone or Initialize Project

```bash
# If starting fresh
npm init -y
npm install next react react-dom

# Or clone existing repository
git clone <repository-url>
cd bittada
```

### Step 2: Install Dependencies

```bash
npm install

# Or with yarn
yarn install

# Or with pnpm
pnpm install
```

### Step 3: PostgreSQL Setup

#### On macOS (using Homebrew)
```bash
# Install PostgreSQL
brew install postgresql@15

# Start PostgreSQL service
brew services start postgresql@15

# Create database
createdb app_db
```

#### On Linux (Ubuntu/Debian)
```bash
# Install PostgreSQL
sudo apt-get update
sudo apt-get install postgresql postgresql-contrib

# Start service
sudo systemctl start postgresql

# Create database
sudo -u postgres createdb app_db
```

#### On Windows
- Download from https://www.postgresql.org/download/windows/
- Run installer and remember the password for `postgres` user
- PostgreSQL will start automatically
- Use pgAdmin GUI or command line to create database

#### Verify Connection
```bash
# Connect to the database
psql postgresql://postgres:postgres@127.0.0.1:5432/app_db

# Should see: app_db=# prompt
# Exit with: \q
```

---

## 🗄️ Database Configuration

### Step 1: Configure Environment

Create `.env` file in project root:

```bash
# .env
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
JWT_SECRET=your-super-secret-jwt-key-change-in-production
NODE_ENV=development
```

### Step 2: Apply Database Schema

The project uses Drizzle ORM for database management.

```bash
# Push schema to database (creates all tables)
npx drizzle-kit push

# Or generate migrations
npx drizzle-kit generate

# View database schema
npx drizzle-kit studio
```

### Step 3: Verify Schema

```bash
# Connect to database
psql postgresql://postgres:postgres@127.0.0.1:5432/app_db

# List all tables
\dt

# Should see 25+ tables:
# - users
# - seller_profiles
# - products
# - orders
# - etc.
```

### Step 4: Database Indexes

Indexes are automatically created during schema push. They are configured on:
- User emails and phone numbers
- Product status, SKU, seller_id
- Order status, customer_id, pickup_code
- Seller verification status
- Complaint status, customer_id
- And more...

---

## 🔐 Environment Variables

### Required Variables

```bash
# Database Connection
DATABASE_URL=postgresql://username:password@host:port/database_name

# Authentication
JWT_SECRET=your-very-secret-key-min-32-chars-recommended
NODE_ENV=development|production
```

### Optional Variables (for future integrations)

```bash
# Payment Gateways
CLICK_API_KEY=
PAYME_API_KEY=
UZCARD_API_KEY=
HUMO_API_KEY=

# File Storage
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
AWS_S3_BUCKET=

# Email Service
SENDGRID_API_KEY=
SMTP_HOST=
SMTP_PORT=
SMTP_USER=
SMTP_PASSWORD=

# SMS/OTP Service
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=

# Logging & Monitoring
SENTRY_DSN=
LOG_LEVEL=info
```

### Environment-Specific Settings

**.env.local** (development):
```bash
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
JWT_SECRET=development-secret-key-not-secure
NODE_ENV=development
```

**.env.production** (deployment):
```bash
DATABASE_URL=postgresql://user:secure-password@prod-host:5432/app_db
JWT_SECRET=production-secret-key-very-long-and-secure
NODE_ENV=production
```

---

## ▶️ Running the Application

### Development Mode

```bash
# Start development server with hot reload
npm run dev

# Server runs on http://localhost:3000
# Open browser and navigate to http://localhost:3000
```

### Production Mode

```bash
# Build for production
npm run build

# Start production server
npm start

# Or deploy to platform (Vercel, Render, etc.)
npm run deploy
```

### Database Studio (Drizzle)

```bash
# Open visual database manager
npx drizzle-kit studio

# Opens in browser at localhost:xxxx
# Can view and edit data directly
```

---

## 🧪 Testing the Complete Flow

### Scenario 1: Customer Journey

#### Step 1: Create Customer Account
```bash
# 1. Open http://localhost:3000
# 2. Click "Ro'yxatdan o'tish" (Register)
# 3. Fill form:
#    - To'liq ismi (Full Name): John Doe
#    - Email: john@example.com
#    - Telefon (Phone): +998901234567
#    - Parol (Password): password123
# 4. Click submit
# 5. Should be logged in and redirected to home
```

#### Step 2: Verify Customer Created
```bash
# In database:
psql postgresql://postgres:postgres@127.0.0.1:5432/app_db

# List users
SELECT id, email, role FROM users WHERE email = 'john@example.com';

# Should return 1 row with role = 'customer'
```

#### Step 3: Browse Marketplace
```bash
# 1. User is on home page
# 2. Should see "Bittada'da hozircha mahsulotlar yo'q" (No products)
# 3. This is correct - no sellers have products yet
```

### Scenario 2: Seller Journey

#### Step 1: Create Seller Account (same email, different user)
```bash
# 1. Open http://localhost:3000/auth/register
# 2. Fill form with seller email:
#    - To'liq ismi: Jane Merchant
#    - Email: jane@example.com
#    - Telefon: +998902345678
#    - Parol: password123
# 3. Choose role: "seller" or use different endpoint
# 4. Click submit
```

#### Step 2: Create Seller Profile
```bash
# 1. Automatically redirect to /seller/register
# 2. Fill seller profile:
#    - Biznes nomi: My Store
#    - Sotuvchi turi: individual
#    - Shahar: Toshkent
#    - Manzil: 123 Main Street
#    - Telefon: +998902345678
# 3. Click "Profil Yaratish" (Create Profile)
# 4. Should see "Sotuvchi profili yaratildi! Admin tomonidan tasdiqlashni kuting."
```

#### Step 3: Verify Seller in Database
```bash
# In database:
SELECT id, business_name, verification_status 
FROM seller_profiles 
WHERE user_id = (SELECT id FROM users WHERE email = 'jane@example.com');

# Should return:
# - id: uuid
# - business_name: My Store
# - verification_status: pending
```

### Scenario 3: Admin Approval Flow

#### Step 1: Create Admin User (database)
```bash
# In database:
INSERT INTO users (
  email, 
  password_hash, 
  full_name, 
  phone, 
  role
) VALUES (
  'admin@example.com',
  'bcrypt_hashed_password',  -- pre-hashed password
  'Admin User',
  '+998903456789',
  'admin'
);
```

#### Step 2: Login as Admin
```bash
# 1. Use /api/auth/login with admin credentials
# 2. Admin token will be returned
# 3. Navigate to http://localhost:3000/admin
```

#### Step 3: Approve Seller
```bash
# Via API:
POST /api/admin/approve-seller
Authorization: Bearer {admin_token}
{
  "seller_id": "uuid-from-database",
  "approved": true
}

# Or manually in database:
UPDATE seller_profiles 
SET verification_status = 'approved', verified_at = NOW()
WHERE user_id = (SELECT id FROM users WHERE email = 'jane@example.com');
```

### Scenario 4: Product Creation & Approval

#### Step 1: Create Product (as Seller)
```bash
# Via API:
POST /api/products/create
Authorization: Bearer {seller_token}
{
  "name": "Sample Product",
  "description": "A great product",
  "price": 50000,
  "stock_quantity": 10,
  "sku": "SKU-001",
  "weight": 500
}

# Response includes:
# - product.id
# - product.status: "draft"
```

#### Step 2: Verify Product Created
```bash
# In database:
SELECT id, name, status, seller_id 
FROM products 
WHERE name = 'Sample Product';

# Should show:
# - status: draft
# - seller_id: (seller's uuid)
```

#### Step 3: Submit for Review (as Seller)
```bash
# Via API:
POST /api/products/submit-for-review
Authorization: Bearer {seller_token}
{
  "product_id": "product-uuid"
}

# In database:
UPDATE products SET status = 'pending_review' WHERE id = 'product-uuid';
```

#### Step 4: Approve Product (as Admin)
```bash
# Via API:
POST /api/admin/approve-product
Authorization: Bearer {admin_token}
{
  "product_id": "product-uuid",
  "approved": true
}

# In database:
UPDATE products SET status = 'approved' WHERE id = 'product-uuid';
```

#### Step 5: Product Appears on Marketplace
```bash
# Via API:
GET /api/products/list

# Should now include the approved product
```

### Scenario 5: Order Creation with Pickup Code

#### Step 1: Create Pickup Point (as Admin)
```bash
# Must have pickup points for orders

# Via API (not yet implemented, do manually):
INSERT INTO pickup_points (
  name, city, address, phone, status
) VALUES (
  'Tashkent Center',
  'Toshkent',
  '123 Main St, Tashkent',
  '+998712345678',
  'active'
);
```

#### Step 2: Add Product to Cart (as Customer)
```bash
# Not yet implemented as separate API
# Would save cart items to database

# Manual database entry for testing:
INSERT INTO cart (customer_id, expires_at)
VALUES (
  'customer-uuid',
  NOW() + INTERVAL '7 days'
);

INSERT INTO cart_items (cart_id, product_id, quantity, price_at_addition)
VALUES (
  'cart-uuid',
  'product-uuid',
  1,
  '50000'
);
```

#### Step 3: Checkout & Create Order
```bash
# Via API:
POST /api/orders/create
Authorization: Bearer {customer_token}
{
  "pickup_point_id": "pickup-point-uuid",
  "payment_method": "cash_on_delivery"
}

# Response includes:
# {
#   "order": {
#     "id": "order-uuid",
#     "order_number": "BT...",
#     "pickup_code": "4827",
#     "total": "50000"
#   }
# }
```

#### Step 4: Verify Unique Pickup Code
```bash
# In database:
SELECT id, order_number, pickup_code, status 
FROM orders 
WHERE order_number = 'BT...';

# Should show:
# - pickup_code: 4827 (unique, random)
# - status: new

# Verify uniqueness:
SELECT COUNT(*) FROM orders WHERE pickup_code = '4827';
# Should return 1 (only one order with this code)
```

#### Step 5: Seller Sees Order
```bash
# Via API:
GET /api/sellers/products (shows orders for seller's products)

# In database:
SELECT o.*, oi.* FROM orders o
JOIN order_items oi ON o.id = oi.order_id
WHERE oi.seller_id = 'seller-uuid';

# Shows:
# - Order with pickup code 4827
# - Customer phone
# - Pickup point
# - Items and prices
```

---

## 🚀 Deployment Guide

### Option 1: Vercel (Recommended)

```bash
# 1. Install Vercel CLI
npm i -g vercel

# 2. Login to Vercel
vercel login

# 3. Deploy
vercel

# 4. Configure environment variables
# In Vercel dashboard:
# - Settings > Environment Variables
# - Add DATABASE_URL
# - Add JWT_SECRET

# 5. Auto-deploys on git push
```

### Option 2: Render.com

```bash
# 1. Create account on render.com
# 2. Create new Web Service
# 3. Connect GitHub repository
# 4. Configure:
#    - Build command: npm run build
#    - Start command: npm start
#    - Environment variables:
#      DATABASE_URL=...
#      JWT_SECRET=...
# 5. Deploy
```

### Option 3: Self-Hosted (VPS)

```bash
# 1. SSH into server
ssh root@server_ip

# 2. Install Node.js
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt-get install nodejs

# 3. Install PM2 (process manager)
npm install -g pm2

# 4. Clone repository
git clone <repo> /app/bittada
cd /app/bittada

# 5. Install dependencies
npm install

# 6. Build
npm run build

# 7. Start with PM2
pm2 start npm --name bittada -- start
pm2 save
pm2 startup

# 8. Setup Nginx reverse proxy
# Create /etc/nginx/sites-available/bittada
# Point to http://localhost:3000
```

### Option 4: Docker

```bash
# Create Dockerfile
# Create docker-compose.yml
# Run:
docker-compose up -d

# App accessible at defined port
```

---

## 📡 API Documentation

### Authentication Endpoints

#### Register Customer
```http
POST /api/auth/register
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "password123",
  "full_name": "John Doe",
  "phone": "+998901234567",
  "role": "customer"
}

Response (201):
{
  "success": true,
  "user": {
    "id": "uuid",
    "email": "user@example.com",
    "full_name": "John Doe",
    "phone": "+998901234567",
    "role": "customer"
  },
  "token": "jwt_token_here"
}
```

#### Login
```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "user@example.com",
  "password": "password123"
}

Response (200):
{
  "success": true,
  "user": { ... },
  "token": "jwt_token_here"
}
```

#### Get Profile
```http
GET /api/auth/profile
Authorization: Bearer {token}

Response (200):
{
  "user": { ... }
}
```

### Seller Endpoints

#### Register Seller Profile
```http
POST /api/sellers/register
Authorization: Bearer {token}
Content-Type: application/json

{
  "business_name": "My Store",
  "seller_type": "individual",
  "address": "123 Main St",
  "city": "Toshkent",
  "phone": "+998901234567",
  "description": "My store description"
}
```

#### Get Seller Profile
```http
GET /api/sellers/profile
Authorization: Bearer {seller_token}
```

#### Get Seller Products
```http
GET /api/sellers/products
Authorization: Bearer {seller_token}
```

### Product Endpoints

#### Create Product
```http
POST /api/products/create
Authorization: Bearer {seller_token}
Content-Type: application/json

{
  "name": "Product Name",
  "description": "Description",
  "price": 50000,
  "category_id": "uuid",
  "sku": "SKU-001",
  "stock_quantity": 10,
  "weight": 500
}
```

#### Submit for Review
```http
POST /api/products/submit-for-review
Authorization: Bearer {seller_token}
Content-Type: application/json

{
  "product_id": "uuid"
}
```

#### List Products
```http
GET /api/products/list?page=1&limit=20
```

### Order Endpoints

#### Create Order
```http
POST /api/orders/create
Authorization: Bearer {customer_token}
Content-Type: application/json

{
  "pickup_point_id": "uuid",
  "payment_method": "cash_on_delivery",
  "customer_notes": "Optional notes"
}
```

### Admin Endpoints

#### Approve Seller
```http
POST /api/admin/approve-seller
Authorization: Bearer {admin_token}
Content-Type: application/json

{
  "seller_id": "uuid",
  "approved": true
}
```

#### Approve Product
```http
POST /api/admin/approve-product
Authorization: Bearer {admin_token}
Content-Type: application/json

{
  "product_id": "uuid",
  "approved": true,
  "reason": "Optional reason if rejected"
}
```

#### Get Sellers
```http
GET /api/admin/sellers?status=pending
Authorization: Bearer {admin_token}
```

#### Get Products for Review
```http
GET /api/admin/products?status=pending_review
Authorization: Bearer {admin_token}
```

### Pickup Points

#### List Pickup Points
```http
GET /api/pickup-points/list?city=Toshkent
```

---

## 🔧 Troubleshooting

### Issue: Database Connection Error

```bash
# Check PostgreSQL is running
psql --version
psql -U postgres -c "SELECT 1"

# Verify DATABASE_URL in .env
cat .env | grep DATABASE_URL

# Test connection manually
psql postgresql://postgres:postgres@127.0.0.1:5432/app_db

# If failed, check credentials and port
sudo netstat -tlnp | grep postgres
```

### Issue: Schema Not Created

```bash
# Verify database exists
psql -U postgres -l | grep app_db

# Check tables
psql postgresql://postgres:postgres@127.0.0.1:5432/app_db -c "\dt"

# Recreate schema
npx drizzle-kit push

# Or reset completely
psql -U postgres -c "DROP DATABASE IF EXISTS app_db;"
psql -U postgres -c "CREATE DATABASE app_db;"
npx drizzle-kit push
```

### Issue: JWT Token Invalid

```bash
# Check JWT_SECRET in .env
cat .env | grep JWT_SECRET

# Ensure it's the same in dev and production
# Token expires after 7 days - users need to re-login

# Test token manually
node -e "const jwt = require('jsonwebtoken'); console.log(jwt.sign({test: true}, 'secret'))"
```

### Issue: Port 3000 Already in Use

```bash
# Find process using port 3000
lsof -i :3000

# Kill process
kill -9 <PID>

# Or use different port
PORT=3001 npm run dev
```

### Issue: Seller Can't Create Products

```bash
# Verify seller is approved
SELECT verification_status FROM seller_profiles 
WHERE user_id = 'user-uuid';

# Must be 'approved', not 'pending'

# If pending, approve as admin
UPDATE seller_profiles 
SET verification_status = 'approved' 
WHERE user_id = 'user-uuid';
```

### Issue: Order Not Created

```bash
# Verify pickup points exist
SELECT * FROM pickup_points WHERE status = 'active';

# If none, create one:
INSERT INTO pickup_points (
  name, city, address, phone, status
) VALUES (
  'Test Point',
  'Toshkent',
  '123 Test St',
  '+998901234567',
  'active'
);

# Verify products are approved
SELECT status FROM products WHERE id = 'product-uuid';

# Must be 'approved'

# Verify stock
SELECT stock_quantity FROM products WHERE id = 'product-uuid';

# Must be > 0
```

---

## 📞 Support & Resources

- **Documentation**: See README.md and FEATURES.md
- **Database Schema**: See src/db/schema.ts
- **API Routes**: See src/app/api/
- **Pages**: See src/app/

---

**BITTADA: Qulaylik. Bittada.**
