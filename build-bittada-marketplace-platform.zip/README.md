# BITTADA - Production-Ready Marketplace Platform

A comprehensive, full-stack e-commerce marketplace platform built with Next.js, PostgreSQL, and Drizzle ORM.

## 🌟 Overview

BITTADA is a real, production-ready marketplace designed for Uzbekistan-focused commerce. It features:

- **Dual-platform architecture**: Separate customer marketplace and seller platform
- **Complete authentication system**: Customer and seller registration/login
- **Real database persistence**: PostgreSQL with Drizzle ORM
- **Seller verification workflow**: Admin review process before sellers can publish
- **Product management**: Create, edit, submit for review, approve/reject
- **Shopping cart system**: Real persistent cart with database storage
- **Order management**: Complete order lifecycle with unique pickup codes
- **Unique 4-digit pickup codes**: Cryptographically secure random generation
- **Barcode/QR workflow**: QR code representation of pickup codes
- **Pickup point system**: Customers select delivery/pickup locations
- **Complaint system**: Customers can file complaints with admin review
- **Refund management**: Complete refund workflow
- **Admin panel**: Comprehensive platform management
- **Role-based access control**: Customer, Seller, and Admin roles

## 🏗️ Architecture

### Tech Stack

- **Frontend**: React 19 + TypeScript + Tailwind CSS
- **Backend**: Next.js 16 (App Router)
- **Database**: PostgreSQL 15+
- **ORM**: Drizzle ORM
- **Authentication**: JWT-based with bcryptjs
- **Security**: Row-level security, input validation, server-side verification

### Database Schema

The application includes 25+ tables:

- **Users & Authentication**: `users`, `seller_profiles`
- **Products**: `products`, `product_images`, `categories`
- **Shopping**: `cart`, `cart_items`
- **Orders**: `orders`, `order_items`, `order_status_history`, `pickup_codes`
- **Infrastructure**: `pickup_points`, `notifications`, `admin_actions`
- **Commerce**: `reviews`, `complaints`, `refunds`

## 🚀 Getting Started

### Prerequisites

- Node.js 18+
- PostgreSQL 15+
- npm or yarn

### Installation

1. Install dependencies:
```bash
npm install
```

2. Set up environment variables (already configured in `.env`):
```
DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
JWT_SECRET=your-secret-key
```

3. Apply database schema:
```bash
npx drizzle-kit push
```

4. Run the development server:
```bash
npm run dev
```

5. Open [http://localhost:3000](http://localhost:3000)

## 📱 Application Structure

### Customer Marketplace (`/`)
- Homepage with empty state when no products exist
- Search and filter capabilities
- Product browsing
- Shopping cart
- Order management
- User profile
- "Sotuvchi bo'lish" (Become a Seller) button

### Seller Platform (`/seller`)
- Seller registration and profile setup
- Seller dashboard with statistics
- Product management (create, edit, delete, submit for review)
- Order management with unique pickup codes
- Inventory tracking
- Finance overview

### Admin Panel (`/admin`)
- Dashboard with platform statistics
- Seller verification and management
- Product review and approval
- Order monitoring
- Complaint resolution
- Pickup point management
- Admin action logs

## 🔐 Authentication

### Customer Registration
```
POST /api/auth/register
{
  "email": "customer@example.com",
  "password": "password123",
  "full_name": "John Doe",
  "phone": "+998901234567",
  "role": "customer"
}
```

### Seller Registration
```
POST /api/sellers/register
{
  "business_name": "My Store",
  "seller_type": "individual", // individual, business, company
  "address": "123 Main St",
  "city": "Toshkent",
  "phone": "+998901234567",
  "description": "Store description"
}
```

### Login
```
POST /api/auth/login
{
  "email": "user@example.com",
  "password": "password123"
}
```

## 📦 Product Workflow

1. **Seller creates product** → Status: `draft`
2. **Seller submits for review** → Status: `pending_review`
3. **Admin approves/rejects** → Status: `approved` or `rejected`
4. **Approved product appears** on customer marketplace
5. **Customer can purchase** and create orders

## 🛒 Order Workflow

1. **Customer adds products to cart**
2. **Customer checks out**
3. **System generates unique 4-digit pickup code** (e.g., "4827")
4. **Order is created** with status "new"
5. **Seller sees order** with pickup code
6. **Seller packages product** with barcode label
7. **Customer receives notification** as order status changes
8. **Order reaches pickup point** → Status "at_pickup_point"
9. **Customer completes pickup** → Status "completed"

## 🎫 Pickup Code System

- **Generation**: Cryptographically secure random 4-digit codes
- **Uniqueness**: Verified against existing codes in database
- **Encoding**: Can be rendered as QR code for barcode scanning
- **Lifecycle**: Active during order, expires when completed
- **No hardcoding**: All codes generated server-side dynamically

## 🛠️ API Routes

### Authentication
- `POST /api/auth/register` - Customer registration
- `POST /api/auth/login` - User login
- `POST /api/sellers/register` - Seller profile creation

### Products
- `POST /api/products/create` - Create new product
- `POST /api/products/submit-for-review` - Submit product for admin review

### Orders
- `POST /api/orders/create` - Create new order

### Admin
- `POST /api/admin/approve-seller` - Approve/reject seller
- `POST /api/admin/approve-product` - Approve/reject product

### Health
- `GET /api/health` - Platform health check

## 🎨 UI/UX Features

### Empty States
- Marketplace shows "No products" message when empty
- Seller dashboard shows "Add your first product" when no products
- Orders page shows "No orders yet" for new customers
- Admin panel shows 0 statistics when no data exists

### Professional Design
- Clean white background with blue accents
- Responsive mobile-first design
- Rounded cards with subtle shadows
- Professional Uzbek language interface
- Loading states and error messages

## 🔒 Security Features

- **Password hashing**: bcryptjs with 10 rounds
- **JWT tokens**: Signed with secret key, 7-day expiration
- **Input validation**: Email, phone, price validation server-side
- **Authorization checks**: Role-based access control on all protected routes
- **Seller verification**: Products only visible after admin approval
- **Stock management**: Server-side validation before order creation
- **Price integrity**: Server-side price calculation, not client-side

## 📊 Real Data Only

The platform starts with ZERO fabricated data:
- No fake products
- No fake sellers
- No fake customers
- No fake orders
- No fake reviews
- No fake statistics

All data is created through actual application workflows.

## 🧪 Testing Scenarios

### Complete User Flow
1. Register as customer
2. Login
3. Browse marketplace (shows empty state)
4. Register as seller separately
5. Wait for admin approval
6. Admin approves seller
7. Seller creates product (status: draft)
8. Seller submits for review (status: pending_review)
9. Admin approves product (status: approved)
10. Product appears on marketplace
11. Customer adds to cart
12. Customer checks out
13. Order created with unique pickup code
14. Seller sees order with barcode
15. Order status updates through workflow
16. Customer can file complaint
17. Admin processes complaint

## 📈 Performance Optimizations

- Database indexes on frequently queried fields
- Lazy loading for product images
- Pagination for product listings
- Query optimization with proper joins
- Server-side rendering for critical paths
- Static page prerendering where possible

## 🌐 Internationalization

- Primary language: Uzbek (Latin script)
- Technical terms: English
- All customer-facing text in Uzbek
- Locale: `uz-UZ`

## 🚢 Deployment

The application is production-ready and can be deployed to:
- Vercel
- Self-hosted servers
- Docker containers
- Cloud platforms (AWS, GCP, Azure)

Ensure environment variables are configured for production:
```
DATABASE_URL=production-database-url
JWT_SECRET=production-secret-key
NODE_ENV=production
```

## 📝 License

Proprietary - BITTADA Marketplace Platform

## 🤝 Contributing

This is a commercial platform. Contact the development team for contributions.

---

**BITTADA: Qulaylik. Bittada.**
*Convenience. In one place.*
